<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


error_reporting(E_COMPILE_ERROR | E_ERROR | E_CORE_ERROR);
require_once('roots.php');
require ($root_path . 'include/inc_environment_global.php');

$limit = $_REQUEST[limit];
$start = $_REQUEST[start];

$task = ($_REQUEST['task']) ? ($_REQUEST['task']) : '';

$ID=$_POST[ID];
$tableName=$_POST[tableName];
$formStatus = $_POST[formStatus];
$userName=$_POST[userName];

switch($task){
    case "updateUser":
        if($formStatus=='insert'){
            insertUser($_POST);
        }else if($formStatus=='update'){
            updateUser($_POST);
        }
        break;
    case "getUsersList":
        getUsersList();
        break;
    case "getRolesList":
        getRolesList();
        break;
    case "getUserRoles":
        getUserRoles();
        break;
    case "deleteUser":
        deleteUser($userName);
        break;
    default:
        echo "{failure:true}";
        break;
}


function deleteUser($userName) {
    global $db;
    $debug = false;
    
    $sql = "delete from proll_users where username='$userName'";
    if ($debug) {
        echo $sql;
    }
    if ($db->Execute($sql)) {
        echo "{success:true}";
    } else {
        echo "{failure:false}";
    }
}

function validateUser($userName){
    global $db;
    $debug=true;
    
    $sql="Select Username from proll_users where Username='$userName'";
    $request=$db->Execute($sql);
    $numRows=$request->RecordCount();
    
    if($numRows>0){
        return TRUE;
    }else{
        return FALSE;
    }
}

function insertUser($userdetails) {
    global $db;
    $debug = false;

    //$table = $registerdetails['formtype'];
    if(validateUser($userdetails['username'])){
        echo '{failure:true,errNo:1}';
    }else{
        unset($userdetails['formStatus']);
         unset($userdetails['ID']);
         
         $userdetails['password']=  md5($userdetails['password']);
         
        foreach ($userdetails as $key => $value) {
            $FieldNames.=$key . ', ';
            $FieldValues.='"' . $value . '", ';
        }

        $sql = 'INSERT INTO proll_users (' . substr($FieldNames, 0, -2) . ') ' .
                'VALUES (' . substr($FieldValues, 0, -2) . ') ';

        if ($debug)
            echo $sql;
        if ($db->Execute($sql)) {
            echo '{success:true}';
        } else {
            echo "{'failure':'true','errNo':'2'}";
        }
    }
}

function updateUser($userdetails) {
    global $db;
    $debug = true;
    $id=$userdetails['ID'];
    $sql = 'UPDATE proll_users SET ';
    unset($userdetails['formStatus']);
     unset($userdetails['ID']);
    $userdetails['password']=  md5($userdetails['password']);
    foreach ($userdetails as $key => $value) {
        $sql .= $key . '="' . $value . '", ';
    }
    $sql = substr($sql, 0, -2) . ' WHERE ID="' . $id . '"';

    if ($debug)
        echo $sql;

    if ($db->Execute($sql)) {
        $results = '{success: true }';
    } else {
        $results = "{success: false,errors:{clientNo:'Could not update User, Please check your values'}}"; // Return the error message(s)
    }
    echo $results;
}


function getUserRoles() {
    global $db;
    $debug = false;

    $userRoles = $_GET[ids];

    $sql = "Select `ID`,`Role`,`View`,`Edit`,`Delete` from proll_roles where ID IN $userRoles";
    if ($debug) echo $sql;
    
    $results = $db->Execute($sql);
    $numRows = $results->RecordCount();

    echo '{"success":"true","roles":[';
    $counter = 0;
    while ($row = $results->FetchRow()) {
        echo '{"Role":"' . $row['Role'] . '","View":"' . $row['View'] . '","Edit":"' . $row['Edit']
        . '","Delete":"' . $row['Delete'] . '"}';
        if ($counter < $numRows) {
            echo ",";
        }
        $counter++;
    }
    echo ']}';
}

function getRolesList() {
    global $db;
    $debug = false;

    $sql = "Select `ID`,`Role`,`View`,`Edit`,`Delete` from proll_roles";
    if ($debug)
        echo $sql;
    $results = $db->Execute($sql);
    $numRows = $results->RecordCount();

    echo '{"success":"true","roles":[';
    $counter = 0;
    while ($row = $results->FetchRow()) {
        echo '{"Role":"' . $row['Role'] . '","View":"' . $row['View'] . '","Edit":"' . $row['Edit']
        . '","Delete":"' . $row['Delete'] . '"}';
        if ($counter < $numRows) {
            echo ",";
        }
        $counter++;
    }
    echo ']}';
}

function getUsersList() {
    global $db;
    $debug = false;

    $sql = "Select ID,FirstName,LastName,Username,Roles from proll_users";
    if ($debug)
        echo $sql;
    $results = $db->Execute($sql);
    $numRows = $results->RecordCount();

    echo '{"success":"true","users":[';
    $counter = 0;
    while ($row = $results->FetchRow()) {
        echo '{"ID":"' . $row['ID'] . '","FirstName":"' . $row['FirstName'] . '","LastName":"' . $row['LastName']
        . '","UserName":"' . $row['Username'] . '","Roles":"' . $row['Roles'] . '"}';

        $counter++;

        if ($counter < $numRows) {
            echo ",";
        }

    }
    echo ']}';
}

