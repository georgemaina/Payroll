
<?php

error_reporting(E_COMPILE_ERROR | E_ERROR | E_CORE_ERROR);
require_once('roots.php');
require ($root_path . 'include/inc_environment_global.php');

//require_once($root_path . 'include/care_api_classes/class_weberp_c2x.php');
//require_once($root_path . 'include/inc_init_xmlrpc.php');
//require_once($root_path . 'include/care_api_classes/class_tz_insurance.php');
//require_once($root_path . 'include/care_api_classes/class_tz_billing.php');
//$insurance_obj = new Insurance_tz;
//$bill_obj = new Bill;

$limit = $_REQUEST[limit];
$start = $_REQUEST[start];

$task = ($_REQUEST['task']) ? ($_REQUEST['task']) : '';

$regDate1 = new DateTime($_POST[dateJoined]);
$dateJoined = $regDate1->format('Y/m/d');
$payMonth = $_REQUEST['payMonth'];
//$empBranch = $_REQUEST['empBranch'];

 if(!empty($_REQUEST['empBranch'])){
     $empBranch = $_REQUEST['empBranch'];
 }elseif(!empty($_SESSION['companyBranch'])){
     $empBranch=$_SESSION['companyBranch'];
 }

$department = $_REQUEST['department'];
$CatID = $_REQUEST['CatID'];
$rptType = $_REQUEST['payType'];

//if ($_REQUEST[formStatus] <> '') {
//  $formStatus = $_REQUEST[formStatus];
//} else {
$formStatus = $_POST[formStatus];
//}

if ($_REQUEST[pid] <> '') {
    $pid = $_REQUEST[pid];
} else {
    $pid = $_POST[pid];
}

if ($_REQUEST[pid2] <> '') {
    $pid2 = $_REQUEST[pid2];
} else {
    $pid2 = $_POST[pid2];
}

if ($_REQUEST[Payment] <> '') {
    $payName = $_REQUEST[Payment];
} else {
    $payName = $_POST[Payment];
}

if ($_REQUEST[PaymentType] <> '') {
    $payType = $_REQUEST[PaymentType];
} else {
    $payType = $_POST[PaymentType];
}

$amount = $_POST[Amount];
$balance = $_POST[Balance];

if (isset($_POST[debtorStatus])) {
    $suspended = 1;
} else {
    $suspended = 0;
}

$user = $_POST[user];
$pass = $_POST[pass];
$password = md5($pass);

switch ($task) {
    case "getPayrollStatus":
        getPayrollStatus($payMonth);
        break;
    case "getEmployeeRecord":
        getEmployeeRecord($start, $limit, $pid);
        break;
    case "getPayDepts":
        getPayDepts();
        break;
    case "getPayBranch":
        getPayBranch();
        break;
    case "getBanks":
        getBanks();
        break;
    case "getBankBranch":
        getBankBranch($bankid);
        break;
    case "getJobTitle":
        getJobTitle();
        break;
    case "getEmpType":
        getEmpType();
        break;
    case "getJobGroup":
        getJobGroup();
        break;
    case "getMaritalStatus":
        getMaritalStatus();
        break;
    case "updateEmployee":
        if ($formStatus == 'update') {
            updateEmployee($_POST);
        } else if ($formStatus == 'insert') {
            insertNewEmployee($_POST);
        }
        break;
    case "getPayTypes":
        getPayTypes($CatID, $start, $limit);
        break;
    case "getPayRates":
        getPayRates();
        break;
    case "getEmpPayments":
        getEmpPayments($pid, $start, $limit);
        break;
    case "getProllPayments":
        getProllPayments($pid,$payMonth,  $CatID, $payType,$start, $limit);
        break;
    case "InsertItem":
        if ($formStatus == 'insert') {
            InsertEmpPayment($pid, $payType, $payName, $amount, $balance);
        } else if ($formStatus == 'update') {
            updateEmpPayment($pid, $payType, $payName, $amount, $balance);
        }
        break;
    case "importPayments":
        importPayments($payMonth);
        break;
    case "getPaymentsSummary":
        getPaymentsSummary($payMonth);
        break;
    case "deletePayment":
        deletePayment($pid, $payName);
        break;
    case "updateTaxes":
        updateTaxes();
        break;
    case "clearImports":
        clearImports($payMonth);
        break;
    case "postPayroll":
        if($empBranch=='MAIN'){
            postPayrollMain($payMonth,$empBranch);
        }else if($empBranch=='CCC'){
            postPayroll($payMonth,$empBranch);
        }
        break;
    case "getCompanyInfo":
        getCompanyInfo();
        break;
    case "updateCompany":
        updateCompany($_POST);
        break;
    case "getSlipEmpInfo":
        getSlipEmpInfo($payMonth, $numCols, $pid, $pid2, $empBranch, $department);
        break;
    case "getNhifReturns":
        getNHIFReturns($payMonth);
        break;
    case "getNssfReturns":
        getNssfReturns($payMonth);
        break;
    case "getPayeReturns":
        getPayeReturns($payMonth);
        break;
    case "getTrialBalance":
        getTrialBalance($payMonth, $empBranch);
        break;
    case "getPostingDetail":   //getPostingDetail($payMonth, $CatID, $PayType, $empBranch, $pid1, $pid2)
        getPostingDetail($payMonth, $payName, $payType, $empBranch, $pid1, $pid2);
        break;
    case "checkLogin":
        checkLogin();
        break;
    case "doLogin":
        doLogin($user, $password);
        break;
    case "doLogout":
        doLogout($user);
        break;
    case "getPayrollListings":
        getPayrollListings($payMonth,$empBranch);
        break;
    case "getPayrollListingsMain":
        getPayrollListingsMain($payMonth,$empBranch);
        break;
    case "getPaycategory":
        getPaycategory();
        break;
    case "getDepartmentTotals":
        getDepartmentTotals($payMonth, $deptName);
        break;
    case "getEarningsDeductions":
        getEarningsDeductions($payMonth, $payType, $rptType);
        break;
    case "getP9Report":
        getP9Report($pid);
        break;
    case "getGratuityRates":
        getGratuityRates();
        break;
    case "getBlankPayments":
        getBlankPayments();
        break;
    case "doCalculations":
        doCalculations($payType,$pid);
        break;
    case "getEmployeesBatchlist":
        getEmployeesBatchlist($payType);
        break;
    default:
        echo "{failure:true}";
        break;
}//end switch

if (!$_SESSION['sess_user_name'])
    $_SESSION['sess_user_name'];
if (!$_SESSION['sess_firstName'])
    $_SESSION['sess_firstName'];
if (!$_SESSION['sess_LastName'])
    $_SESSION['sess_LastName'];
if (!$_SESSION['sess_company'])
    $_SESSION['sess_company'];

    //Items are 0 Pid=4 EmpNames=GLADYS MWAURA WANGARI Amount=2000 Balance=
    //Items are 1 Pid=6 EmpNames=KELLEN  KAWIRA Amount=3000 Balance=


function getEmployeesBatchlist($payType){
    global $db;
    $debug=false;

    $sql="SELECT e.`pid`,CONCAT(r.`FirstName`,' ',r.`LastName`,' ',r.`Surname`) AS empNames,e.`PayType`,e.`PayName`,e.`Amount` FROM `proll_emp_payments` e
            INNER JOIN `proll_empregister` r ON e.`pid`=r.`PID` WHERE e.`PayName`='$payType'";

    if($debug) echo $sql;

    $results=$db->Execute($sql);
    $rcount=$results->RecordCount();

    if($rcount>0){
        echo '{"BatchEmployeesList":[';
        $counter=0;
        while($row=$results->FetchRow()){
            echo '{"pid":"'.$row['pid'].'","empNames":"'.$row['empNames'].'","payType":"'.$row['PayType'].'","payName":"'.$row['PayName']
                .'","Amount":"'.$row['Amount'].'"}';

            $counter++;

            if($counter<$rcount){
                echo ',';
            }
        }

        echo ']}';
    }
}

function setGratuityAmount($paytype,$pid){
    global $db;
    $debug=false;

    $sql="Select * from proll_paytypes where ID='$paytype'";
    if($debug) echo $sql;

    $results=$db->Execute($sql);
    $rcount=$results->RecordCount();

    if($rcount>0){
        $row=$results->FetchRow();

        $sql2="SELECT r.pid,r.`GratuityRates`,p.`Amount` FROM `proll_empregister` r LEFT JOIN `proll_emp_payments` p
                ON r.`PID`=p.`pid` WHERE p.`PayName`='001' AND r.`GratuityRates` IS NOT NULL and r.pid='$pid'";

        $result=$db->Execute($sql2);
        $row2=$result->FetchRow();

        $amount=$row2['GratuityRates']/100*$row2['Amount'];

        echo '{"Results":[{"success":"true","calculated":"'.$amount.'"}]}';
    }else{
        echo "{failure:true}";
    }
}

function setCalculatedAmount($paytype,$pid){

}

function doCalculations($paytype,$pid){
    global $db;
    $debug=false;

    $sql="Select * from proll_paytypes where ID='$paytype'";
    if($debug) echo $sql;

    $results=$db->Execute($sql);
    $rcount=$results->RecordCount();

    if($rcount>0){
        $row=$results->FetchRow();

        if($row['Calculated']=='Yes' and $paytype='110'){
            setGratuityAmount($paytype,$pid);
        }else{
            setCalculatedAmount($paytype,$pid);
        }
//        echo '{"Results":[{"success":"true","calculated":"'.$row['Calculated'].'"}]}';
    }else{
        echo "{failure:true}";
    }
}

function checkIfPaymentExists($pid,$paytype){
    global $db;
    $debug=false;

    $sql="Select * from proll_emp_payments where pid='$pid' and payname='$paytype'";
    if($debug) echo $sql;
    $results=$db->Execute($sql);
    $rcount=$results->RecordCount();

    if($rcount>0){
        return true;
    }else{
        return false;
    }
}

 function  InsertPaymentType($pid,$catID,$payName,$amount,$balance){
     global $db;
     $debug=false;

     $sql="INSERT INTO `proll_emp_payments` (`pid`,`PayType`,`PayName`, `Amount`,`Balance`)
            VALUES('$pid','$catID','$payName','$amount','$balance')" ;
     if($debug) echo $sql;

     if($db->Execute($sql)){
         $error=0;
     }else{
         $error=1;
     }

     return $error;
 }


    function  UpdatePaymentType($pid,$catID,$payName,$amount,$balance){
        global $db;
        $debug=false;

        $sql="UPDATE `proll_emp_payments` SET `pid`='$pid',`PayType`='$catID',`PayName`='$payName', `Amount`='$amount',`Balance`='$balance'
                WHERE `pid`='$pid' and `PayName`='$payName'";
        if($debug) echo $sql;

        if($db->Execute($sql)){
            $error=0;
        }else{
            $error=1;
        }

        return $error;
    }

 function getBlankPayments(){
     global $db;
     $debug=false;

     $strAction=$_POST['savePostings'];
     $paytype=$_POST['paytype'];
     $catID=$_POST['CatID'];
        $strData=json_decode($strAction,true);

     $error=0;
     if(!empty($strData)){
             foreach ($strData as $key=>$value) {
               //  echo " Items are ". $key;
                 foreach($value as $k=>$val){
                    // echo " ".$k."=".$val;
                     if($k=='Pid') $pid=$val;
                     if($k=='Amount') $amount=$val;
                     if($k=='Balance') $balance=$val;
                 }

                 if(checkIfPaymentExists($pid,$paytype)){
                     // echo "Payment already Exists";
                     UpdatePaymentType($pid,$catID,$paytype,$amount,$balance);
                 }else{
                     // echo "Payment Does not Exists";
                     InsertPaymentType($pid,$catID,$paytype,$amount,$balance);
                 }
             }
         if($error==0){
             echo "{success:true}";
         }else{
             echo "{failure:true}";
         }
         //getPaymentsItems();
     }else{
            getPaymentsItems();
     }
 }

    function getPaymentsItems(){
        global $db;
        $debug=false;

        $sql="SELECT r.`PID`,CONCAT(r.`FirstName`,' ',r.`LastName`,' ',r.`Surname`) AS empNames,' ' AS `Amount`,' ' AS `Balance`
            FROM proll_empregister r";
        if($debug) echo $sql;

        $result=$db->Execute($sql);
        $strCount=$result->RecordCount();

        echo '{"total":'.$strCount.',"blankPayments":[';
        $counter=0;
        while($row=$result->FetchRow()){
            echo '{"Pid":"'.$row[PID].'","EmpNames":"'.$row[empNames].'","Amount":"'.$row[Amount].'","Balance":"'.$row[Amount].'"}';

            $counter++;
            if($counter<$strCount){
                echo ",";
            }

        }

        echo "]}";
    }

 function getGratuityRates(){
        global $db;
        $debug=false;

        $sql="Select rate from proll_rates where ID=33";
        if($debug) echo $sql;
        $result=$db->Execute($sql);
        $row=$result->FetchRow();

        $rates=explode(',',$row[0]);
        $strCount=count($rates);

        echo "{'total':$strCount,'rates':[";
        foreach($rates as $strRates){
            echo "{'rate':'$strRates'},";
        }

        echo "]}";

 }

function getPaycategory() {
    global $db;
    $debug = false;

    $sql = "Select ID,CatName from proll_paycategory";
    if ($debug) {
        echo $sql;
    }

    $result = $db->Execute($sql);
    $numRows = $result->RecordCount();
    echo '{
    "totalCount":"' . $numRows . '","paycategories":[';
    $counter = 0;
    while ($row = $result->FetchRow()) {
        echo '{"ID":"' . $row[ID] . '","CatName":"' . $row[CatName] . '"}';
        $counter++;
        if ($counter <> $numRows) {
            echo ",";
        }
    }
    echo ']}';
}


    function getPayrollListings($payMonth, $payBranch) {
        global $db;
        $debug = false;

        $sql = "SELECT Pid,EmpNames,JobTitle,EmpBranch,PayMonth,`001` AS BasicPay,`112` as SpecialRisk,`012` AS RiskAllowance,
                `108` AS ResponsibilityAllowance,`073` AS LeaveAllowance,`109` as FieldAllowance,`005` AS HouseAllowance,
                `110` as Gratuity,`121` AS Medical,`114` AS GrossSalary,`013` AS PAYE,`016` AS NSSF,`019` AS NHIF,`133` AS Loans,`051` AS Advance,
                `091` as Insurance,`124` AS Helb,`110` as GratuityB,`121` as MedicalB,`111` as Welfare,`115` as Deductions,`113` as NetPay
                FROM proll_listings where payMonth='$payMonth' ";

        if ($payBranch <> '') {
            $sql.=" AND EmpBranch='$payBranch'";
        }

        if ($debug)
            echo $sql;
        $request = $db->Execute($sql);
        $numRows = $request->RecordCount();

        echo '{
    "totalCount":"' . $numRows . '","payrolllistings":[';
        $counter = 0;
        while ($row = $request->FetchRow()) {
            //$names = trim(preg_replace('/[^a-zA-Z0-9_ -]/s', '', $row[emp_names]));
            echo '{"Pid":"' . $row[Pid] . '","EmpNames":"' . $row[EmpNames] . '","JobTitle":"' . $row[JobTitle] . '","EmpBranch":"' . $row[EmpBranch] . '","PayMonth":"' . $row[PayMonth]
                . '","BasicPay":"' . $row[BasicPay] . '","SpecialRisk":"' . $row[SpecialRisk] . '","RiskAllowance":"' . $row[RiskAllowance] . '","ResponsibilityAllowance":"' . $row[ResponsibilityAllowance]
                . '","LeaveAllowance":"' . $row[LeaveAllowance] . '","FieldAllowance":"' . $row[FieldAllowance] . '","HouseAllowance":"' . $row[HouseAllowance]
                . '", "Gratuity":"' . $row[Gratuity] . '","Medical":"' . $row[Medical] . '","GrossSalary":"' . $row[GrossSalary]
                . '", "PAYE":"' . $row[PAYE] . '","NSSF":"' . $row[NSSF] . '","NHIF":"' . $row[NHIF] . '","Loans":"' . $row[Loans]
                . '","Advance":"' . $row[Advance] . '","Insurance":"' . $row[Insurance] . '","Helb":"' . $row[Helb] . '","GratuityB":"' . $row[GratuityB]
                . '","MedicalB":"' . $row[MedicalB] . '","Welfare":"' . $row[Welfare] . '","Deductions":"' . $row[Deductions] . '","NetPay":"' . $row[NetPay]. '"}';
            if ($counter < $numRows) {
                echo ",";
            }
            $counter++;
        }
        echo ']}';
    }

function getPayrollListingsMain($payMonth, $payBranch) {
    global $db;
    $debug = false;

    $sql = "SELECT Pid,EmpNames,JobTitle,EmpBranch,PayMonth,`001` AS BasicPay,`005` AS HouseAllowance,`108` AS RespAllowance,`125` AS `SPRES_Allowance`,`126` AS `LS_Allowance`,`012` AS RiskAllowance
            ,`044` AS CallAllowance,`128` AS PHAllowance,`123` AS TravelAllowance,`073` AS leaveAllowance,`129` AS Extra,`127` AS Others,`114` AS GrossPay,`013` AS PAYE,`016` AS NSSF,
            `016` AS NHIF,`064` AS NNAK,`067` AS Waumini,`020` AS `Union`,`051` AS Advance,`018` AS COOPLoan,`106` AS BBKLoan,`124` AS HELB,`111` AS Welfare,`130` AS JoyHome,
            `031` AS Electricity,`030` AS Water,`094` AS HouseMaintenance,`115` AS TotalDeductions,`131` AS OtherRefunds,`132` AS TotalPay,`113` AS NetPay
            FROM proll_listings_Main WHERE payMonth='$payMonth'";

    if ($payBranch <> '') {
        $sql.=" AND EmpBranch='$payBranch'";
    }

    if ($debug)
        echo $sql;
    $request = $db->Execute($sql);
    $numRows = $request->RecordCount();

    echo '{
    "totalCount":"' . $numRows . '","payrolllistingsmain":[';
    $counter = 0;
    while ($row = $request->FetchRow()) {
        //$names = trim(preg_replace('/[^a-zA-Z0-9_ -]/s', '', $row[emp_names]));
        echo '{"Pid":"' . $row[Pid] . '","EmpNames":"' . $row[EmpNames] . '","JobTitle":"' . $row[JobTitle] . '","EmpBranch":"' . $row[EmpBranch]
            . '","PayMonth":"' . $row[PayMonth] . '","BasicPay":"' . $row[BasicPay] . '","HouseAllowance":"' . $row[HouseAllowance]
        . '","RespAllowance":"' . $row[RespAllowance] . '","SPRES_Allowance":"' . $row[SPRES_Allowance] . '","LS_Allowance":"' . $row[LS_Allowance]
        . '", "RiskAllowance":"' . $row[RiskAllowance] . '","CallAllowance":"' . $row[CallAllowance] . '","PHAllowance":"' . $row[PHAllowance]
        . '", "TravelAllowance":"' . $row[TravelAllowance] . '","leaveAllowance":"' . $row[leaveAllowance] . '","Extra":"' . $row[Extra]
        . '","Others":"' . $row[Others] . '","GrossPay":"' . $row[GrossPay] . '","PAYE":"' . $row[PAYE]  . '","NSSF":"' . $row[NSSF] . '","NHIF":"' . $row[NHIF] . '","NNAK":"' . $row[NNAK]
            . '","Waumini":"' . $row[Waumini] . '","Union":"' . $row[Union] . '","Advance":"' . $row[Advance] . '","COOPLoan":"' . $row[COOPLoan] . '","BBKLoan":"' . $row[BBKLoan]
            . '","HELB":"' . $row[HELB] . '","Welfare":"' . $row[Welfare] . '","JoyHome":"' . $row[JoyHome] . '","Electricity":"' . $row[Electricity] . '","Water":"' . $row[Water]
            . '","HouseMaintenance":"' . $row[HouseMaintenance] . '","TotalDeductions":"' . $row[TotalDeductions] . '","OtherRefunds":"' . $row[OtherRefunds] . '","TotalPay":"' . $row[TotalPay]
            . '","NetPay":"' . $row[NetPay] . '"}';

        $counter++;
        if ($counter < $numRows) {
            echo ",";
        }
    }
    echo ']}';
}

function doLogin($user, $password) {
    global $db;
    $debug = false;

    $sql = "Select ID,FirstName,LastName,Username,Roles,loginStatus from proll_users where Username='$user' and `password`='$password'";
    if ($debug)
        echo $sql;
    $results = $db->Execute($sql);
    $numRows = $results->RecordCount();
    $row = $results->FetchRow();
    if ($numRows > 0) {
        $loginDate=date("Y-m-d H:m:i");
        $_SESSION['userID']=$user;
        $sql2 = "Update proll_users set loginStatus=1,lastloginDate='$loginDate' where Username='$user'";
        if ($db->Execute($sql2)) {

            echo '{"success":"true","Error":"0","UserName":"' . $_SESSION['sess_user_name'] . '"}';
        }
    } else {
        if ($row[loginStatus] == 1) {
            echo '{"success":"true","Error":"1"}';
        } else {
            echo '{"success":"true","Error":"2"}';
        }
    }
}

function doLogout($user) {
    global $db;
    $debug = true;
    $sql2 = "Update proll_users set loginStatus=0 where Username='$user'";
    if ($db->Execute($sql2)) {
        $_SESSION['userID']='';
        echo '{"success":"true","Error":"0","UserName":"' . $user . '"}';
    } else {
        echo '{"failure":"true"}';
    }
}

function checkUserSession(){
    if($_SESSION['userID']==''){
        if (!empty($_SERVER['HTTPS']) && ('on' == $_SERVER['HTTPS'])) {
            $uri = 'https://';
        } else {
            $uri = 'https://';
        }
        $uri .= $_SERVER['HTTP_HOST'];
        header('Location: '.$uri.'/payroll/');
        //exit;
    }else{
        return false;
    }
}

function checkLogin() {
    global $db;
    $debug = false;

    $username = $_SESSION['userID'];

    $sql = "SELECT CompanyName,firstname,lastname,username,roles FROM proll_company,proll_users WHERE proll_users.`Username`='$username'";
    $results = $db->Execute($sql);
    if ($debug)
        echo $sql;
    //if (!empty($username)) {
    echo '{"success":"true","defaultItems":[';
    // $counter = 0;
    while ($row = $results->FetchRow()) {
        echo '{"FirstName":"' . $row['firstname'] . '","LastName":"'
        . $row['lastname'] . '","Username":"' . $row['username'] . '",
		            "Roles":"' . $row['roles'] . '","CompanyName":"' . $row['CompanyName'] . '"}';
        // if ($counter < $numRows) {
        //     echo ",";
        // }
        // $counter++;
    }
    echo ']}';
//    } else {
//        echo '{"failure":"true"}';
//    }
}

function getEarningsDeductions($payMonth, $payType, $rptType) {
    global $db;
    $debug = false;

    $payType = $_REQUEST[PaymentType];

    $sql = "SELECT p.`ID`,p.`Pid`,p.`emp_names`,p.`catID`,p.`pay_type`,p.`amount`,p.`Balance` FROM `proll_payments` p 
        LEFT JOIN proll_paytypes k ON p.pay_type=k.PayType 
         left join proll_empregister r on p.pid=r.pid 
         where p.paymonth='$payMonth'";

    if ($payType <> '') {
        $sql = $sql . " and p.CatID = '$payType'";
    }

//    if ($PayType <> '') {
//        $sql = $sql . " and p.pay_type = '$payType'";
//    }
//
//    if ($empBranch <> '') {
//        $sql = $sql . " and r.empBranch = '$empBranch'";
//    }


    $sql = $sql . " ORDER BY k.ID";
    if ($debug) {
        echo $sql;
    };

    $result = $db->Execute($sql);
    $numRows = $result->RecordCount();


    echo '{
    "totalCount":"' . $numRows . '","EarningsDeductions":[';
    $counter = 0;
    while ($row = $result->FetchRow()) {
        //$names = trim(preg_replace('/[^a-zA-Z0-9_ -]/s', '', $row[emp_names]));
        echo '{"ID":"' . $row[ID] . '","PID":"' . $row[Pid] . '","EmpNames":"' . $row[emp_names] . '","Category":"' . $row[catID] . '","PayType":"' . $row[pay_type] . '",
            "Amount":"' . number_format($row[amount], 2) . '","Balance":"' . $row[Balance] . '"}';
        if ($counter < $numRows) {
            echo ",";
        }
        $counter++;
    }
    echo ']}';
}

function getPostingDetail($payMonth, $CatID, $PayType, $empBranch, $pid1, $pid2) {
    global $db;
    $sql = "SELECT p.`ID`,p.`Pid`,p.`emp_names`,p.`catID`,p.`pay_type`,p.`amount`,p.`payDate`,p.`payMonth` FROM `proll_payments` p 
        LEFT JOIN proll_paytypes k ON p.pay_type=k.PayType 
         left join proll_empregister r on p.pid=r.pid 
         where p.paymonth='$payMonth'";

    if ($CatID <> '') {
        $sql = $sql . " and p.CatID = '$CatID'";
    }

    if ($PayType <> '') {
        $sql = $sql . " and p.pay_type = '$PayType'";
    }

    if ($empBranch <> '') {
        $sql = $sql . " and r.empBranch = '$empBranch'";
    }


    $sql = $sql . " ORDER BY p.Pid,P.ID ASC";
    //echo $sql;

    $result = $db->Execute($sql);
    $numRows = $result->RecordCount();


    echo '{
    "totalCount":"' . $numRows . '","pstDetail":[';
    $counter = 0;
    while ($row = $result->FetchRow()) {
        $names = trim(preg_replace('/[^a-zA-Z0-9_ -]/s', '', $row[emp_names]));
        echo '{"ID":"' . $row[ID] . '","PID":"' . $row[Pid] . '","Emp_Names":"' . $row[emp_names] . '","Category":"' . $row[catID] . '","Pay_Type":"' . $row[pay_type] . '",
            "Amount":"' . number_format($row[amount], 2) . '","PayDate":"' . $row[payDate] . '","Pay_Month":"' . $row[payMonth] . '"}';
        if ($counter < $numRows) {
            echo ",";
        }
        $counter++;
    }
    echo ']}';
}

function getTrialBalance($payMonth, $empBranch) {
    global $db;
    $debug = false;

    $sql = "SELECT t.id,p.pay_type,IF(p.Catid IN ('Earnings','Benefits'),SUM(p.amount),'') AS debit,IF(p.Catid IN ('Deductions','Other','Tax'),
            SUM(p.amount),'') AS credit FROM proll_payments P 
            LEFT JOIN proll_paytypes t ON p.pay_type=t.PayType
            LEFT JOIN proll_empregister r on p.pid=r.pid 
            WHERE p.payMonth='$payMonth' ";

    if ($empBranch <> '') {
        $sql = $sql . " and r.EmpBranch like '$empBranch%'";
    }
    $sql = $sql . " GROUP BY p.pay_type ORDER BY t.ID asc";
    if ($debug) {
        echo $sql;
    }
    $request = $db->Execute($sql);
    $numRows = $request->RecordCount();

    echo '{
    "trialbalance":[';
    $counter = 0;
    while ($row = $request->FetchRow()) {
        $pay_type = $desc = preg_replace('/[^a-zA-Z0-9_ -]/s', '', $row[pay_type]);
        $debit = ($row[debit] > 0) ? number_format($row[debit], 2) : "";
        $credit = ($row[credit] > 0) ? number_format($row[credit], 2) : "";

        echo '{"PayCode":"' . $row[id] . '","Pay_Type":"' . $pay_type . '","Debit":"' . $debit
        . '","Credit":"' . $credit . '"}';
        $counter++;
        if ($counter <> $numRows) {
            echo ",";
        }
    }
    echo ']}';
}

function getDepartmentTotals($payMonth, $deptName) {
    global $db;
    $debug = false;

    $sql = "SELECT t.id,p.pay_type,IF(p.Catid IN ('Earnings','Benefits'),SUM(p.amount),'') AS debit,IF(p.Catid IN ('Deductions','Other','Tax'),
            SUM(p.amount),'') AS credit FROM proll_payments P 
            LEFT JOIN proll_paytypes t ON p.pay_type=t.PayType
            LEFT JOIN proll_empregister r on p.pid=r.pid 
            LEFT JOIN proll_departments d on r.department=d.`ID`
            WHERE p.payMonth='$payMonth' ";

    if ($deptName <> '') {
        $sql = $sql . " and d.`deptName` like '$deptName%'";
    }
    $sql = $sql . " GROUP BY p.pay_type ORDER BY t.ID asc";
    if ($debug) {
        echo $sql;
    }
    $request = $db->Execute($sql);
    $numRows = $request->RecordCount();

    echo '{
    "trialbalance":[';
    $counter = 0;
    while ($row = $request->FetchRow()) {
        $pay_type = $desc = preg_replace('/[^a-zA-Z0-9_ -]/s', '', $row[pay_type]);
        $debit = ($row[debit] > 0) ? number_format($row[debit], 2) : "";
        $credit = ($row[credit] > 0) ? number_format($row[credit], 2) : "";

        echo '{"PayCode":"' . $row[id] . '","Pay_Type":"' . $pay_type . '","Debit":"' . $debit
        . '","Credit":"' . $credit . '"}';
        $counter++;
        if ($counter <> $numRows) {
            echo ",";
        }
    }
    echo ']}';
}

function getPayeReturns($payMonth) {
    global $db;

    $sql = "SELECT p.`Pid`, p.`emp_names`,p.`pay_type`, p.`amount`,e.ID_no,e.Pin_No,p.payMonth FROM proll_payments p inner join proll_empregister e
        on p.Pid=e.PID where pay_type ='PAYE'";

    if (isset($payMonth)) {
        $sql.=" and p.payMonth='$payMonth'";
    }
    $results = $db->Execute($sql);

    $numRows = $results->RecordCount();
    echo '{
    "PayeList":[';
    $counter = 0;
    while ($row = $results->FetchRow()) {
        $emp_names = $desc = preg_replace('/[^a-zA-Z0-9_-]/s', '', $row[emp_names]);
        $pay_type = $desc = preg_replace('/[^a-zA-Z0-9_-]/s', '', $row[pay_type]);


        echo '{"pid":"' . $row[Pid] . '","empNames":"' . $emp_names . '","pay_type":"' . $pay_type . '","Amount":"' . $row[amount] . '","ID_No":"' . $row[4]
        . '","PinNo":"' . $row[Pin_No] . '","payMonth":"' . $row[payMonth] . '"}';
        if ($counter <> $numRows) {
            echo ",";
        }
        $counter++;
    }
    echo ']}';
}

function getNssfRates(){
    global $db;
    $sql="Select value from proll_rates where ID=32";
    $result=$db->Execute($sql);
    $row=$result->FetchRow();
    
    return $row[0];
}

function getNssfReturns($payMonth) {
    global $db;

    $sql = "SELECT p.`Pid`, p.`emp_names`,p.`pay_type`, p.`amount` AS Self,'' AS Company,'' AS Amount,e.ID_No,e.NSSF_No,p.payMonth FROM proll_payments p INNER JOIN proll_empregister e
        ON p.Pid=e.PID WHERE pay_type ='N.S.S.F'";

    if (isset($payMonth)) {
        $sql.=" and p.payMonth='$payMonth'";
    }
    $results = $db->Execute($sql);

    $numRows = $results->RecordCount();
    echo '{
    "NssfList":[';
    $counter = 0;
    $nssfCompany=getNssfRates();
    while ($row = $results->FetchRow()) {
        $emp_names = $desc = preg_replace('/[^a-zA-Z0-9_ -]/s', '', $row[emp_names]);
        $pay_type = $desc = preg_replace('/[^a-zA-Z0-9_ -]/s', '', $row[pay_type]);


        echo '{"pid":"' . $row[Pid] . '","empNames":"' . $emp_names . '","pay_type":"' . $pay_type 
                . '","Self":"' . $row['Self']. '","Company":"' . $nssfCompany. '","Amount":"' . intval($row['Self']+$nssfCompany) . '","ID_No":"' . $row[ID_No]
        . '","NSSFNo":"' . $row[NSSF_No] . '","payMonth":"' . $row[payMonth] . '"}';
        if ($counter <> $numRows) {
            echo ",";
        }
        $counter++;
    }
    echo ']}';
}

function getNHIFReturns($payMonth) {
    global $db;

    $sql = "SELECT p.`Pid`, p.`emp_names`,p.`pay_type`, p.`amount`,e.ID_no,e.NHIF_No,p.payMonth FROM proll_payments p inner join proll_empregister e
        on p.Pid=e.PID where pay_type ='N.H.I.F'";

    if (isset($payMonth)) {
        $sql.=" and p.payMonth='$payMonth'";
    }
    $results = $db->Execute($sql);

    $numRows = $results->RecordCount();
    echo '{
    "NhifList":[';
    $counter = 0;
    while ($row = $results->FetchRow()) {
        $emp_names = $desc = preg_replace('/[^a-zA-Z0-9_ -]/s', '', $row[emp_names]);
        $pay_type = $desc = preg_replace('/[^a-zA-Z0-9_ -]/s', '', $row[pay_type]);


        echo '{"pid":"' . $row[Pid] . '","empNames":"' . $emp_names . '","pay_type":"' . $pay_type . '","Amount":"' . $row[amount] . '","ID_No":"' . $row[4]
        . '","NHIFNo":"' . $row[NHIF_No] . '","payMonth":"' . $row[payMonth] . '"}';
        if ($counter <> $numRows) {
            echo ",";
        }
        $counter++;
    }
    echo ']}';
}

function getSlipEmpInfo($payMonth, $numCols, $pid, $pid2, $empBranch, $department) {
    global $db;
    $debug = false;

    $sql = "SELECT p.ID,c.companyname,p.pid,CONCAT(p.firstname,' ',p.lastname,' ',p.surname) AS empNames,p.empBranch,p.department,
           p.`Pin_NO` FROM proll_empregister p, proll_company c
           where c.companyname<>''";

    if ($pid <> '' && $pid2 == '') {
        $sql.= " and p.pid='$pid'";
    }

    if ($pid <> '' && $pid2 <> '') {
        $sql.= " and p.pid between '$pid' and '$pid2'";
    }

    if ($department <> '') {
        $sql.= " and p.department='$department'";
    }

    if ($empBranch <> '') {
        $sql.= " and p.empBranch='$empBranch'";
    }

    $sql.=' order by p.Pid asc';

    if ($debug) {
        echo $sql;
    }
    $result = $db->Execute($sql);
    $numRows = $result->RecordCount();
    echo '{"StaffList":[';
    $counter = 0;
    $numCols = 0;
    $taxCharged = 0;
    while ($row = $result->FetchRow()) {
        if ($numCols < 4) {
            $numCols++;
        } else {
            $numCols = 1;
        }

        $sumsql = "select pid,sum(amount) as grosspay from proll_payments where catID IN('Earnings','Benefits') 
        and pid='$row[pid]' and payMonth='$payMonth'";
        //echo $sumsql;
        $sumresult = $db->Execute($sumsql);
        $sumRows = $sumresult->FetchRow();
        $gloss = $sumRows[1];

        $pyesql = 'select amount from proll_payments where pid="' . $row[pid] . '" and pay_type="paye" and paymonth="' . $payMonth . '"';
        $pyeresult = $db->Execute($pyesql);
        $pyerow = $pyeresult->FetchRow();
        $txCharged = $pyerow[0];

        $isql = "SELECT amount,t.`ReliefPercentage` FROM proll_payments p LEFT JOIN proll_paytypes t 
                    ON P.`pay_type`=T.`PayType`
                    WHERE pid='$row[pid]' AND paymonth='$payMonth' AND T.`TaxRelief`='on'";
        $iresult = $db->Execute($isql);
        $irow = $iresult->FetchRow();
        $insuranceRelief = $irow[0] * $irow[1];

        $pyesql = 'select amount from proll_payments where pid="' . $row[pid] . '" and pay_type="Personal Relief" and paymonth="' . $payMonth . '"';
        $pyeresult = $db->Execute($pyesql);

        $pyerow = $pyeresult->FetchRow();
        $txRelief = $pyerow[0];

        $pyesql1 = 'select amount from proll_payments where pid="' . $row[pid] . '" and pay_type="paye"
        and paymonth="' . $payMonth . '"';
        $pyeresult1 = $db->Execute($pyesql1);
        $pyerow1 = $pyeresult1->FetchRow();
        $txCharged = $pyerow1[0];
        $tx = $txCharged;

        $dsql3 = "SELECT sum(Amount) as amount FROM proll_payments WHERE pid='$row[pid]' AND catid='Deductions' and paymonth='$payMonth'";
        if ($debug) {
            echo $dsql3;
        }
        $requestd = $db->Execute($dsql3);
        $numRowsd = $requestd->FetChRow();
        $totalDeductions = $numRowsd[0] + $tx;

        $netPay = $gloss - $totalDeductions;

        $dsqlr = "SELECT * FROM proll_rates";
        $requestr = $db->Execute($dsqlr);
        while ($numRowsr = $requestr->FetchRow()) {
            if ($numRowsr[RateName] == 'NSSF COMPANY') {
                $nssfCo = $numRowsr[Value];
            }
        }

        //$topMessage = $desc = preg_replace('/[^a-zA-Z0-9_ -]/s', '', $row[TopMessage]);
        $period = date('F-y');
        echo '{"ColNumber":"' . $numCols . '","pid":"' . $row[pid] . '","ID":"' . $row[ID] . '","CompanyName":"' . $row[companyname] . '","empNames":"' . $row[empNames] . '","empBranch":"' . $row[empBranch]
        . '","department":"' . $row[department] . '","Pin_NO":"' . $row[Pin_NO] . '","GrossPay":"' . number_format($gloss, 2) . '","InsuranceRelief":"' . number_format($insuranceRelief, 2) . '","TaxDeducted":"' . number_format($tx, 2)
        . '","period":"' . $period . '","NssfCompany":"' . number_format($nssfCo, 2) . '","TotalDeduction":"' . number_format($totalDeductions, 2) . '","NetPay":"' . number_format($netPay, 2)
        . '","Earnings":[';

        $sql2 = "Select pid,catID,Pay_type,Amount,Balance from proll_payments where pid='$row[pid]' and catid IN ('Earnings','Benefits') and paymonth='$payMonth'";
        if ($debug) {
            echo $sql2;
        }
        $request2 = $db->Execute($sql2);
        $numRows2 = $request2->RecordCount();
        $count2 = 0;

        while ($row2 = $request2->FetchRow()) {

            echo '{"pid":"' . $row2[pid] . '","catID":"' . $row2[catID] . '","PayType":"' . $row2[Pay_type] . '","Amount":"' . number_format($row2[Amount], 2)
            . '","Balance":"' . number_format($row2[Balance], 2) . '"}';
            $count2++;
            if ($count2 <> $numRows2) {
                echo ",";
            }
        }

        echo '],"TaxDeductions":[';

        $sql3 = "SELECT pid,catID,Pay_type,Amount,Balance FROM proll_payments
                 WHERE pid='$row[pid]' AND 
                 pay_type IN('PENSION','N.S.S.F','PAYE','Personal Relief') and paymonth='$payMonth'";
        if ($debug) {
            echo $sql3;
        }
        $request3 = $db->Execute($sql3);
        $numRows3 = $request3->RecordCount();
        $count3 = 0;

        while ($row3 = $request3->FetchRow()) {
            echo '{"pid":"' . $row3[pid] . '","catID":"' . $row3[catID] . '","PayType":"' . $row3[Pay_type] . '","Amount":"' . number_format($row3[Amount], 2)
            . '","Balance":"' . number_format($row3[Balance], 2) . '"}';
            $count3++;

            if ($count3 <> $numRows3) {
                echo ",";
            }
        }

        echo '],"Information":[';

        $sql3 = "SELECT pid,catID,Pay_type,Amount,Balance FROM proll_payments
                 WHERE pid='$row[pid]' AND 
                 pay_type IN('GRATUITY','N.S.S.F') and paymonth='$payMonth'";
        if ($debug) {
            echo $sql3;
        }
        $request3 = $db->Execute($sql3);
        $numRows3 = $request3->RecordCount();
        $count3 = 0;

        while ($row3 = $request3->FetchRow()) {
            echo '{"pid":"' . $row3[pid] . '","catID":"' . $row3[catID] . '","PayType":"' . $row3[Pay_type] . '","Amount":"' . number_format($row3[Amount], 2)
            . '","Balance":"' . number_format($row3[Balance], 2) . '"}';
            $count3++;

            if ($count3 <> $numRows3) {
                echo ",";
            }
        }

        echo '],"Deductions":[';

        $sql4 = "SELECT pid,catID,Pay_type,Amount,Balance FROM proll_payments WHERE pid='$row[pid]' AND 
                catid IN('Deductions') and paymonth='$payMonth'";
        if ($debug) {
            echo $sql4;
        }
        $request4 = $db->Execute($sql4);
        $numRows4 = $request4->RecordCount();
        $count4 = 0;
        while ($row4 = $request4->FetchRow()) {
            echo '{"pid":"' . $row4[pid] . '","catID":"' . $row4[catID] . '","PayType":"' . $row4[Pay_type] . '","Amount":"' . number_format($row4[Amount], 2)
            . '","Balance":"' . number_format($row4[Balance], 2) . '"}';
            $count4++;
            if ($count4 <> $numRows4) {
                echo ",";
            }
        }

        echo ']}';

        $counter++;
        if ($counter <> $numRows) {
            echo ",";
        }
    }
    echo ']}';
}

function updateCompany($companyDetails) {
    global $db;
    $debug = false;
    $sql = 'UPDATE proll_Company SET ';
    unset($companyDetails['formStatus']);
    foreach ($companyDetails as $key => $value) {
        $sql .= $key . '="' . $value . '", ';
    }
    $sql = substr($sql, 0, -2) . ' WHERE ID="1"';

    if ($debug)
        echo $sql;

    if ($db->Execute($sql)) {
        $results = '{success: true }';
    } else {
        $results = "{success: false,errors:{clientNo:'Could not update Debtor, Please check your values'}}"; // Return the error message(s)
    }
    echo $results;
}

function getCompanyInfo() {
    global $db;
    $debug = false;

    $sql = "SELECT
            `ID`,`CompanyName`,`Address`,`Postal`,`Phone`,`PhysicalAddress`,`Town`,`Country`,`Email`,`Website`,
            `PinNo`,`VatNo`,`IncNo`,`BankAccountNO`,`TopMessage`,`BottomMessage`,`EmployeeStatus`,`OtherInfo`,`MoreInfo`,`CompanyBranch`
          FROM `proll_company`";
    if ($debug) {
        echo $sql;
    }
    $request = $db->Execute($sql);
    $numRows = $request->RecordCount();
    echo '{
    "companyInfo":[';
    $counter = 0;
    while ($row = $request->FetchRow()) {
        $topMessage = $desc = preg_replace('/[^a-zA-Z0-9_ -]/s', '', $row[TopMessage]);
        echo '{"ID":"' . $row[ID] . '","CompanyName":"' . $row[CompanyName] . '","Address":"' . $row[Address] . '","Postal":"' . $row[Postal]
        . '","Phone":"' . $row[Phone] . '","PhysicalAddress":"' . $row[PhysicalAddress] . '","Town":"' . $row[Town] . '","Country":"' . $row[Country]
        . '","Email":"' . $row[Email] . '","Website":"' . $row[Website] . '","PinNo":"' . $row[PinNo] . '","VatNo":"' . $row[VatNo]
        . '","IncNo":"' . $row[IncNo] . '","BankAccountNO":"' . $row[BankAccountNO] . '","TopMessage":"' . $topMessage
        . '","BottomMessage":"' . $row[BottomMessage] . '","EmployeeStatus":"' . $row[EmployeeStatus]
        . '","OtherInfo":"' . $row[OtherInfo] . '","MoreInfo":"' . $row[MoreInfo] . '","CompanyBranch":"' . $row[CompanyBranch]  . '"}';
        $counter++;
        if ($counter <> $numRows) {
            echo ",";
        }
    }
    echo ']}';
}



    function updatePayrollpostingsMain($payMonth) {
        global $db;
        $debug = true;

        $sql = "SHOW COLUMNS FROM proll_listings_main";
        if ($debug) {
            echo $sql;
        }
        $request = $db->Execute($sql);
        $fieldnames = array();
        while ($row = $request->FetchRow()) {
            $fieldnames[] = $row[Field];
        }

        $sql3 = "SELECT p.`pid`,p.`emp_names`,t.`ID`,p.`Pay_Type`,p.`amount`,t.`CatID` FROM proll_payments p LEFT JOIN `proll_paytypes` t ON p.`pay_type`=t.`PayType`
                    WHERE p.payMonth='$payMonth'";
        if ($debug) {
            echo $sql3;
        }
        $request3 = $db->Execute($sql3);
        $gross = 0;
        while ($row = $request3->FetchRow()) {

            foreach ($fieldnames as $values) {
                if ($values == $row[ID]) {
                    $sqlInsert = "Update proll_listings_main set `$values`=$row[amount] where pid='$row[pid]'";
                    if ($debug)
                        echo $sqlInsert;
                }
                $db->Execute($sqlInsert);
            }
        }


        $sqlInsert2 = "Update proll_listings_main l set `114`=(select sum(p.amount) as total from proll_payments p where p.pid=l.pid and p.CatID IN('Earnings','Benefits')) ";
        if ($debug)
            echo $sqlInsert2;
        $db->Execute($sqlInsert2);

        $sqlInsert3 = "Update proll_listings_main l set `115`=(select sum(p.amount) as total from proll_payments p where p.pid=l.pid and p.CatID in ('Deductions','Tax'))";
        if ($debug)
            echo $sqlInsert3;
        $db->Execute($sqlInsert3);
    }

function updatePayrollpostings() {
    global $db;
    $debug = false;

    $sql = "SHOW COLUMNS FROM proll_listings";
    if ($debug) {
        echo $sql;
    }
    $request = $db->Execute($sql);
    $fieldnames = array();
    while ($row = $request->FetchRow()) {
        $fieldnames[] = $row[Field];
    }

    $sql3 = "SELECT p.`pid`,p.`emp_names`,t.`ID`,p.`Pay_Type`,p.`amount`,t.`CatID` FROM proll_payments p LEFT JOIN `proll_paytypes` t ON p.`pay_type`=t.`PayType`";
    if ($debug) {
        echo $sql3;
    }
    $request3 = $db->Execute($sql3);
    $gross = 0;
    while ($row = $request3->FetchRow()) {

        foreach ($fieldnames as $values) {
            if ($values == $row[ID]) {
                $sqlInsert = "Update proll_listings set `$values`=$row[amount] where pid='$row[pid]'";
                if ($debug)
                    echo $sqlInsert;
            }
            $db->Execute($sqlInsert);
        }
    }


    $sqlInsert2 = "Update proll_listings l set `114`=(select sum(p.amount) as total from proll_payments p where p.pid=l.pid and p.CatID IN('Earnings','Benefits')) ";
    if ($debug)
        echo $sqlInsert2;
    $db->Execute($sqlInsert2);

    $sqlInsert3 = "Update proll_listings l set `115`=(select sum(p.amount) as total from proll_payments p where p.pid=l.pid and p.CatID in ('Deductions','Tax'))";
    if ($debug)
        echo $sqlInsert3;
    $db->Execute($sqlInsert3);
}

function getEmpBenefits($pid, $payMonth) {
    global $db;
    $debug = false;

    $sql = "SELECT pid, p.`pay_type`,amount FROM proll_payments p LEFT JOIN `proll_paytypes` t ON p.`pay_type`=t.`PayType`
            WHERE pid='$pid' AND payMonth='$payMonth' AND p.CatID='Benefits' AND t.showinBoth IS NULL";
    if ($debug) {
        echo $sql;
    }
    $results = $db->Execute($sql);
    $row = $results->FetchRow();

    return $row[0];
}

function getEmpGross($pid, $payMonth) {
    global $db;
    $debug = false;

    $sql = "Select sum(amount) as amount from proll_payments where pid='$pid' and payMonth='$payMonth' AND CatID IN ('Earnings','Benefits')";
    if ($debug) {
        echo $sql;
    }
    $results = $db->Execute($sql);
    $row = $results->FetchRow();

    return $row[0];
}

function getEmpBasic($pid, $payMonth) {
    global $db;
    $debug = false;

    $sql = "Select sum(amount) as amount from proll_payments where pid='$pid' and payMonth='$payMonth' AND Pay_type='Basic Pay'";
    if ($debug) {
        echo $sql;
    }
    $results = $db->Execute($sql);
    $row = $results->FetchRow();

    return $row[0];
}

function getEmpTaxRelief($pid, $payMonth) {
    global $db;
    $debug = false;

    $sql = "Select sum(amount) as amount from proll_payments where pid='$pid' and payMonth='$payMonth' AND CatID='Relief'";
    if ($debug) {
        echo $sql;
    }
    $results = $db->Execute($sql);
    $row = $results->FetchRow();

    return $row[0];
}

    function postPayrollMain($payMonth,$branch) {
        global $db;
        $debug = true;

        $sql1 = "INSERT INTO `proll_listings_Main`
            (`PID`,`EMPNAMES`,`JobTitle`,EmpBranch,PayMonth) SELECT DISTINCT e.pid,CONCAT(TRIM(e.firstname),' ',TRIM(e.lastname),' ',TRIM(e.Surname)) AS empNames,
                e.JobTitle,'$branch','$payMonth' FROM proll_empregister e LEFT JOIN proll_emp_payments p ON e.`PID`=p.`pid`";
        if ($debug) {
            echo $sql1;
        }
        if ($db->Execute($sql1)) {

        updatePayrollpostingsMain($payMonth,$branch);

        updateP9($payMonth);

        $sql3 = "Insert into proll_hist(pid,EmpBranch,department,section,CatID,Pay_Type,Amount,Balance,postingMonth,postingYear,inputuser,postingDate)
            select p.pid,r.EmpBranch,r.`Department`,r.`Section`,
            p.`catID`,p.`pay_type`,p.`amount`,p.`Balance`,p.`payMonth`,Year(p.`payDate`) as postingYear,'inputuser',
            date(Now()) as postingDate from proll_payments p
             left join `proll_empregister` r on p.`Pid`=r.`PID` where status='Open' and payMonth='$payMonth'";
        if ($debug) {
            echo $sql3;
        }

        if ($db->Execute($sql3)) {
            $sql4 = "update proll_payments set `status`='POSTED' where payMonth='$payMonth'";
            if ($debug) {
                echo $sql4;
            }
            if ($db->Execute($sql4)) {

                $sql2 = "Update proll_emp_payments set imported=0";
                if ($db->Execute($sql2)) {
                    echo '{success:true}';
                } else {
                    echo '{failure:true}';
                }
            }
        }
    }
    }

function postPayroll($payMonth,$branch) {
    global $db;
    $debug = false;

    $sql1 = "INSERT INTO `proll_listings`
            (`PID`,`EMPNAMES`,`JobTitle`,EmpBranch,PayMonth) SELECT DISTINCT e.pid,CONCAT(TRIM(e.firstname),' ',TRIM(e.lastname),' ',TRIM(e.Surname)) AS empNames,
                e.JobTitle,e.EmpBranch,'$payMonth' FROM proll_empregister e LEFT JOIN proll_emp_payments p ON e.`PID`=p.`pid`";
    if ($debug) {
        echo $sql1;
    }
    if ($db->Execute($sql1)) {

        updatePayrollpostings();

        updateP9($payMonth);

        $sql3 = "Insert into proll_hist(pid,EmpBranch,department,section,CatID,Pay_Type,Amount,Balance,postingMonth,postingYear,inputuser,postingDate)
            select p.pid,r.EmpBranch,r.`Department`,r.`Section`,
            p.`catID`,p.`pay_type`,p.`amount`,p.`Balance`,p.`payMonth`,Year(p.`payDate`) as postingYear,'inputuser',
            date(Now()) as postingDate from proll_payments p
             left join `proll_empregister` r on p.`Pid`=r.`PID` where status='Open' and payMonth='$payMonth'";
        if ($debug) {
            echo $sql3;
        }

        if ($db->Execute($sql3)) {
            $sql4 = "update proll_payments set `status`='POSTED' where payMonth='$payMonth'";
            if ($debug) {
                echo $sql4;
            }
            if ($db->Execute($sql4)) {

                $sql2 = "Update proll_emp_payments set imported=0";
                if ($db->Execute($sql2)) {
                    updateBalances($payMonth);
                } else {
                    echo '{failure:true}';
                }
            }
        }
    }
}

function updateBalances($payMonth){
    global $db;
    $debug=false;

    $sql="SELECT e.pid,e.`PayName`,e.`Amount`,e.`Balance`,p.`BalanceStatus` FROM `proll_emp_payments` e
            LEFT JOIN `proll_paytypes` p ON e.`PayName`=p.`ID`
          WHERE balance IS NOT NULL";
      if($debug) echo $sql;
    $results=$db->Execute($sql);
    $error=0;
    while($row=$results->FetchRow()){
        if($row[BalanceStatus]=='Increasing'){
            $balance=$row[Amount]+$row[Balance];
            $sql2="Update proll_emp_payments set Balance='$balance' where pid='$row[pid]' and PayName='$row[PayName]'";
        }else if($row[BalanceStatus]=='Reducing'){
            $balance=$row[Amount]-$row[Balance];
            if($balance>0){
                $sql2="Update proll_emp_payments set Balance='$balance' where pid='$row[pid]' and PayName='$row[PayName]'";
            }else{
                $sql2="Delete from proll_emp_payments where pid='$row[pid]' and PayName='$row[PayName]'";
            }
        }
        if($debug) echo $sql2;
        if($db->Execute($sql2)){
            $error=0;
        }else{
            $error=$error+1;
        }
    }
    if($error=0){
        echo "{success:true}";
    }else{
        echo "{failure:true}";
    }

}

function getP9Report($pid) {
    global $db;
    $debug = false;

    $sql = "SELECT `ID`,`PID`,`payrollMonth`,`ColumnA`,`ColumnB`,`ColumnC`,`ColumnD`,
            `ColumnE1`,`ColumnE2`,`ColumnE3`,`ColumnF`,`ColumnG`,`ColumnH`,`ColumnJ`,`ColumnK`,`ColumnL`
          FROM `chak_payroll`.`proll_p9a`";

    if ($pid <> '') {
        $sql.=" where pid='$pid'";
    }

    $result = $db->Execute($sql);
    $numRows = $result->RecordCount();

    echo '{
    "total":"' . $numRows . '","p9report":[';
    $counter = 0;
    while ($row = $result->FetchRow()) {

        echo '{"ID":"' . $row[ID] . '","PID":"' . $row[PID] . '","payrollMonth":"' . $row[payrollMonth] . '","ColumnA":"' . $row[ColumnA]
        . '","ColumnB":"' . $row[ColumnB] . '","ColumnC":"' . $row[ColumnC] . '","ColumnD":"' . $row[ColumnD] . '","ColumnE1":"' . $row[ColumnE1]
        . '","ColumnE2":"' . $row[ColumnE2] . '","ColumnE3":"' . $row[ColumnE3] . '","ColumnF":"' . $row[ColumnF] . '","ColumnG":"' . $row[ColumnG]
        . '","ColumnH":"' . $row[ColumnH] . '","ColumnJ":"' . $row[ColumnJ] . '","ColumnK":"' . $row[ColumnK] . '","ColumnL":"' . $row[ColumnL] . '"}';

        if ($counter <> $numRows) {
            echo ",";
        }
        $counter++;
    }
    echo ']}';
}

function updateP9($payMonth) {
    global $db;
    $debug = false;

    $payYear = date("Y");
    $sql1 = "INSERT INTO `proll_p9a`
            (`PID`,`EMPNAMES`,payrollMonth,payrollYear) SELECT DISTINCT e.pid,CONCAT(TRIM(e.firstname),' ',TRIM(e.lastname),' ',TRIM(e.Surname)) AS empNames,
                '$payMonth','$payYear' FROM proll_empregister e";
    if ($debug) {
        echo $sql1;
    }
    if ($db->Execute($sql1)) {

        $sql = "SHOW COLUMNS FROM proll_p9a";
        if ($debug) {
            echo $sql;
        }
        $request = $db->Execute($sql);
        $fieldnames = array();
        while ($row = $request->FetchRow()) {
            $fieldnames[] = $row[Field];
        }

        $sql = "Select pid,payrollMonth from proll_p9a";
        //echo $sql;
        $result = $db->Execute($sql);
        while ($row = $result->FetchRow()) {
            updateP9Payments($row[pid], $row[payrollMonth], $fieldnames);
        }
    }
}

function updateP9Payments($pid, $payMonth, $fieldnames) {
    global $db;
    $debug = false;

    $sql = "SELECT `PID`,`CatID`,`pay_Type`,Amount FROM proll_payments WHERE pid='$pid' AND `payMonth`='$payMonth'";
    if ($debug) {
        echo $sql;
    }
    $results = $db->Execute($sql);
    $e1 = 0;
    $e2 = 0;
    $e3 = 0;
    $lowest = 0;
    $tax = 0;
    $relief = 0;
    while ($row = $results->FetchRow()) {
        foreach ($fieldnames as $field) {
            switch ($field) {
                case "ColumnA" && $row[CatID] == 'Earnings';   // Basic pay
                    $amount = $row[Amount];
                    updateP9Amounts("ColumnA", number_format($amount, 0, "", ""), $pid, $payMonth);
                    break;
                case "ColumnB" && $row[CatID] == 'Benefits'; // Benefits
                    $amount = getEmpBenefits($pid, $payMonth);
                    updateP9Amounts("ColumnB", number_format($amount, 0, "", ""), $pid, $payMonth);
                    break;
                case "ColumnC"; //15% of column A and B minus Rent Paid
                    $amount = 0;
                    updateP9Amounts("ColumnC", number_format($amount, 0, "", ""), $pid, $payMonth);
                    break;
                case "ColumnD";  //Gross Pay  A + B + C
                    $amount = getEmpGross($pid, $payMonth);
                    updateP9Amounts("ColumnD", number_format($amount, 0, "", ""), $pid, $payMonth);
                    break;
                case "ColumnE1";
                    $amount = 0.3 * getEmpBasic($pid, $payMonth);  //3% of Basic Pay
                    $e1 = $amount;
                    updateP9Amounts("ColumnE1", number_format($amount, 0, "", ""), $pid, $payMonth);
                    break;
                case "ColumnE2";
                    $amount = 0.1 * getEmpBasic($pid, $payMonth); //10% of Basic Pay
                    $e2 = $amount;
                    updateP9Amounts("ColumnE2", number_format($amount, 0, "", ""), $pid, $payMonth);
                    break;
                case "ColumnE3";  //Fixed Monthly limit
                    $amount = "20000";
                    $e3 = $amount;
                    updateP9Amounts("ColumnE3", number_format($amount, 0, "", ""), $pid, $payMonth);
                    break;
                case "ColumnF";
                    $amount = "12500"; //Standard amount of allowable interest Ksh 12000 per Month
                    updateP9Amounts("ColumnF", number_format($amount, 0, "", ""), $pid, $payMonth);
                    break;
                case "ColumnG";  //lowest of all Es
                    $lowest = min($e1, $e2, $e3);
                    $amount = $lowest + 12500;
                    updateP9Amounts("ColumnG", number_format($amount, 0, "", ""), $pid, $payMonth);
                    break;
                case "ColumnH"; //column D less G
                    $gross = getEmpGross($pid, $payMonth);
                    $amount = $gross - $lowest;
                    updateP9Amounts("ColumnH", number_format($amount, 0, "", ""), $pid, $payMonth);
                    break;
                case "ColumnJ"; //Calculated tax
                    $tax = getAmount($pid);
                    $amount = $tax;
                    updateP9Amounts("ColumnJ", number_format($amount, 0, "", ""), $pid, $payMonth);
                    break;
                case "ColumnK"; //Monthly Relief
                    $relief = getEmpTaxRelief($pid, $payMonth);
                    $amount = $relief;
                    updateP9Amounts("ColumnK", number_format($amount, 0, "", ""), $pid, $payMonth);
                    break;
                case "ColumnL"; //Calculated tax
                    $amount = $tax - $relief;
                    updateP9Amounts("ColumnL", number_format($amount, 0, "", ""), $pid, $payMonth);
                    break;
//                default:
//                    return "Error";
//                    break;
            }
        }
    }
}

function updateP9Amounts($field, $amount, $pid, $payMonth) {
    global $db;
    $debug = false;
    $sql = "Update proll_p9a set $field='$amount' where pid='$pid' and payrollMonth='$payMonth'";
    $db->Execute($sql);
    if ($debug) {
        echo $sql;
    }
}

    function posted($payMonth){
        global $db;
        $debug=false;

        $sql="Select * from proll_payments where status='POSTED' And payMonth='$payMonth'";
        $results=$db->Execute($sql);
        $rcount=$results->RecordCount();

        if($rcount>0){
            return true;
        }else{
            return false;
        }
    }



function clearImports($payMonth) {
    global $db;
    $debug = true;

    if(posted($payMonth)){
        echo '{"success":false,"errorNo":"1"}';
    }else{
        $sql = "Delete from proll_payments where payMonth='$payMonth'";
       if ($debug) {
            echo $sql;
        }
        if ($db->Execute($sql)) {
            $sql2="update proll_emp_payments set approved=0, imported=0";
            if($db->Execute($sql2)){
                echo '{"success":true}';
            }else{
                echo '{"success":false}';
            }
        } else {
            echo '{"success":false}';
        }

     }

}

function getAmount($pid) {
    global $db;

    $sql2 = 'select lower_limit,upper_limit,`value`,`rate` from proll_rates where RateName like "income%"';
    $result2 = $db->Execute($sql2);
    while ($row = $result2->FetchRow()) {
        $data[1][] = $row[0];
        $data[2][] = $row[1];
        $data[3][] = $row[2];
        $data[4][] = $row[3];
    }

    $sql3 = 'select lower_limit,upper_limit,`value`,`rate` from proll_rates where RateName like "Personal R%"';
    $result3 = $db->Execute($sql3);
    $row3 = $result3->FetchRow();
    $relief = $row3[0];

    $sql = 'Select pid,amount from proll_emp_payments where payname="016" and pid="' . $pid . '"';
    $result1 = $db->Execute($sql);
    $nsRow = $result1->FetchRow();
    $nssf = $nsRow[1];

    $sql = 'Select pid,amount from proll_emp_payments where payname="014" and pid="' . $pid . '"';
    $result1 = $db->Execute($sql);
    $nsRow = $result1->FetchRow();
    $pension = $nsRow[1];

    $sql = "SELECT p.pid,p.payname,t.`ReliefPercentage`,p.amount FROM proll_emp_payments p LEFT JOIN proll_paytypes t ON p.`PayType`=t.`ID` WHERE pid='$pid'
                AND t.TaxRelief='ON'";
    $result = $db->Execute($sql);
    $row = $result->FetchRow();
    $insuranceRelief = $row[amount] * $row[ReliefPercentage];


    $sql = "Select pid,sum(amount) from proll_emp_payments where paytype in (1,2) and pid='$pid' 
        AND PayName IN (SELECT ID FROM proll_paytypes WHERE taxDeduct='ON')";
    $result = $db->Execute($sql);
    while ($row = $result->FetchRow()) {
        $pay = $row[1] - $nssf-$insuranceRelief-$pension;

        if ($pay < $data[2][0]) {
            $finaltax = 0;
        } else if ($pay == $data[2][0]) {
            $finaltax = $data[3][0] / 100 * $data[4][0];
        } else if ($pay > $data[1][1] && $pay <= $data[2][1]) {
            $tax = $data[3][0] / 100 * $data[4][0];
            $balTax = $pay - $data[4][0];
            $k = $data[3][1] / 100 * $balTax;
            $finaltax = $tax + $k;
        } else if ($pay > $data[1][2] && $pay <= $data[2][2]) {
            $tax = $data[3][0] / 100 * $data[4][0];
            $tax2 = $data[3][1] / 100 * $data[4][1];
            $balTax = $pay - ($data[4][0] + $data[4][1]);
            $k = $data[3][2] / 100 * $balTax;
            $finaltax = $tax + $k + $tax2;
        } else if ($pay > $data[1][3] && $pay <= $data[2][3]) {
            $tax = $data[3][0] / 100 * $data[4][0];
            $tax2 = $data[3][1] / 100 * $data[4][1];
            $tax3 = $data[3][2] / 100 * $data[4][2];
            $balTax = $pay - ($data[4][0] + $data[4][1] + $data[4][2]);
            $k = $data[3][3] / 100 * $balTax;
            $finaltax = $tax + $k + $tax2 + $tax3;
        } else if ($pay > $data[1][4]) {
            $tax = $data[3][0] / 100 * $data[4][0];
            $tax2 = $data[3][1] / 100 * $data[4][1];;
            $tax3 = $data[3][2] / 100 * $data[4][2];
            $tax4 = $data[3][3] / 100 * $data[4][3];
            $balTax = $pay-($data[4][0] + $data[4][1] + $data[4][2] + $data[4][3]);
            $k = $data[3][4] / 100 * $balTax;
            $finaltax = $tax + $k + $tax2 + $tax3 + $tax4;
        } else {
            $finaltax = 0;
        }

//        }
    }

    return $finaltax;
}

function updateTaxes() {
    global $db;
    $payMonth = $_POST['payMonth'];
    $sql2 = 'Select a.pid,concat(b.surname," ",b.firstname," ",b.lastname) as empnames, a.amount from proll_emp_payments a
                inner join proll_empregister b on a.pid=b.pid where a.payname=1';
    $result2 = $db->Execute($sql2);
    while ($row = $result2->FetchRow()) {
        $sql3 = "select pid,pay_type from proll_payments where pid='" . $row[0] . "' and pay_type IN('PAYE','Personal Relief')
            and payMonth='" . $payMonth . "'";
        $result = $db->Execute($sql3);
        $numRows = $result->RecordCount();
        if ($numRows < 1) {
            $amount = getAmount($row[0]);
            $paye=$amount-1162;
            $sql = 'insert into proll_payments(pid,emp_names,catid,pay_type,amount,payDate,payMonth,status,balance)
                    values("' . $row[0] . '","' . $row[1] . '","TAX","PAYE","' . $paye . '","' . date("Y-m-d") . '","' . $payMonth . '","Open","0.00")';
            $db->Execute($sql);
            echo $sql;

            $sql2 = 'insert into proll_payments(pid,emp_names,catid,pay_type,amount,payDate,payMonth,status,balance)
                    values("' . $row[0] . '","' . $row[1] . '","Relief","Personal Relief","1162","' . date("Y-m-d") . '","' . $payMonth . '","Open","0.00")';
            $db->Execute($sql2);

            $netPay = getNetPay($row[0],$payMonth);
            $sql3 = 'insert into proll_payments(pid,emp_names,catid,pay_type,amount,payDate,payMonth,status,balance)
                    values("' . $row[0] . '","' . $row[1] . '","Others","NET PAY","' . $netPay . '","' . date("Y-m-d") . '","' . $payMonth . '","Open","0.00")';
            $db->Execute($sql3);
//            echo $sql2;
            echo '{success:true}';
        } else {
            echo '{failure:true}';
        }
    }
}

function getPaytypeByName($payName) {
    global $db;

    $sql = "Select ID from proll_paytypes where paytype='$payName'";
    if ($request = $db->Execute($sql)) {
        $row = $request->FetchRow();
        return $row[0];
    } else {
        return 0;
    }
}

function deletePayment($pid, $payName) {
    global $db;
    $debug = true;
    $payName = getPaytypeByName($payName);
    $sql = "delete from proll_emp_payments where pid='$pid' and payName='$payName'";
    if ($debug) {
        echo $sql;
    }
    if ($db->Execute($sql)) {
        echo "{success:true}";
    } else {
        echo "{failure:false}";
    }
}

    //0724447719 Alex Techno Brain

    function getPayrollStatus($payMonth){
        global $db;

        $sql="SELECT payMonth,STATUS FROM proll_payments WHERE payMonth='$payMonth' GROUP BY paymonth";
        $results=$db->Execute($sql);
        $rowCount=$results->RecordCount();

        if($rowCount>0){
            $row=$results->FetchRow();
            echo '{"PayrollStatus":[{"prollStatus":"'.$row[STATUS].'"}]}';
        }else{
            echo '{"PayrollStatus":[{"prollStatus":"nil"}]}';
        }
    }

function getPaymentsSummary($payMonth) {
    global $db;
    $debug =false;

    $sql = "SELECT pid,emp_names,`status` FROM proll_payments where payMonth='$payMonth' GROUP BY pid";
    if ($debug)
        echo $sql;

    $result = $db->Execute($sql);
    $numRows = $result->RecordCount();
    echo '{"paymentsSummaryItems":[';
    $counter = 0;
    while ($row = $result->FetchRow()) {
        $netPay = getNetPay($row[pid],$payMonth);
        echo '{"PID":"' . $row[pid] . '","emp_names":"' . $row[emp_names] . '","total":"' . $netPay . '","pstatus":"' . $row[status] . '"}';
        $counter++;
        if ($counter <> $numRows) {
            echo ",";
        }
    }
    echo ']}';
}
    //8072

    function getExtraEarnings($pid,$payMonth){
        global $db;
        $debug=false;

        $sql="Select pid,p.`pay_type`,sum(amount) as amount from proll_payments p left join proll_paytypes t on p.pay_type=t.paytype
                where p.pid='$pid' and p.paymonth='$payMonth' and t.showinBoth='Yes' and t.`CatID`=3 GROUP BY p.`catID`";
        if($debug) echo $sql;
        $results=$db->Execute($sql);

        $extraEarnings=0;
        while($row=$results->FetchRow()){
            $extraEarnings=$extraEarnings+$row[amount];
        }

        return $extraEarnings;
    }


    function getExtraDeductions($pid,$payMonth){
        global $db;
        $debug=false;

        $sql="Select pid,p.`pay_type`,sum(amount) as amount from proll_payments p left join proll_paytypes t on p.pay_type=t.paytype
                where p.pid='$pid' and p.paymonth='$payMonth' and t.showinBoth='Yes' GROUP BY p.`catID`";
        if($debug) echo $sql;
        $results=$db->Execute($sql);

        $extraDeductions=0;
        while($row=$results->FetchRow()){
            $extraDeductions=$extraDeductions+$row[amount];
        }

        return $extraDeductions;
    }

    function getGrossPay($pid,$payMonth){
        global $db;
        $debug=false;

        $sql = 'select pid,sum(amount) as grosspay from proll_payments where catID IN("Earnings","Benefits")
            and pid="' . $pid . '" and paymonth="' . $payMonth . '" AND pay_type<>"PENSION"';

        if($debug) echo $sql;

        $result = $db->Execute($sql);
        $numRows = $result->RecordCount();
        $sumRows = $result->FetchRow();

        if($numRows>0){
            return $sumRows[1];
        }else{
            return '0';
        }

    }

    function getTax($pid,$payMonth){
        global $db;
        $debug=false;

        $sql = "select pid,sum(amount) as tax from proll_payments where catID='Tax'
            and pid='$pid' and paymonth='$payMonth'";

        if($debug) echo $sql;

        $result = $db->Execute($sql);
        $numRows = $result->RecordCount();
        $sumRows = $result->FetchRow();

        if($numRows>0){
            return $sumRows[1];
        }else{
            return '0';
        }

    }

    function getDeductions($pid,$payMonth){
        global $db;
        $debug=false;

        $sql = 'select sum(a.amount) as deductions FROM proll_payments a
                inner join proll_paytypes b on a.pay_type=b.PayType
                inner join proll_paycategory c on b.CatID=c.ID
                where a.catid="Deductions" and amount>0 and pid="' . $pid . '" and a.paymonth="' . $payMonth . '"';
        $result = $db->Execute($sql);
        $numRows = $result->RecordCount();

        if($numRows>0){
            $rows=$result->FetchRow();
            return $rows[0];
        }else{
            return '0';
        }
    }

    function checkCompanyBranch(){
        global $db;

        $sql="Select CompanyBranch from proll_company";
        $result=$db->Execute($sql);
        $row=$result->FetchRow();

        Return $row[CompanyBranch];
    }

    function getNetPay($pid,$payMonth) {
       // global $db;
        //$debug = false;

        $extraEarnings=getExtraEarnings($pid,$payMonth);
        $extraDeductions=getExtraDeductions($pid,$payMonth);

        $earnings=getGrossPay($pid,$payMonth);
        if(checkCompanyBranch()=="CCC"){
            $gross=$earnings+$extraEarnings;
        }else{
            $gross=$earnings;
        }
        $tax=getAmount($pid);
        $relief=getEmpTaxRelief($pid,$payMonth);
        if(checkCompanyBranch()=="CCC"){
            $deduction=getDeductions($pid,$payMonth);
            $deductions=$deduction+$extraDeductions;
        }else{
            $deductions=getDeductions($pid,$payMonth);
        }

        $deduct =  $deductions+($tax-$relief);
        $netPay =$gross  - $deduct;
        return $netPay;
    }

    function importPayments($payMonth) {
        global $db;
        $debug = true;

        $sql = "SELECT b.pid,CONCAT( b.surname,' ', b.firstname ,' ', b.LastName) AS empnames,DATE(NOW()) AS payDay,
                    'Open' AS STATUS,'$payMonth' AS payMonth,k.catname,j.`paytype`,p.amount,p.Balance,j.showinBoth FROM proll_empregister b
                     INNER JOIN  proll_emp_payments p ON b.pid=p.pid
                    INNER JOIN proll_paycategory k ON k.id=p.PayType
                    INNER JOIN proll_paytypes j ON j.id=p.PayName
                    WHERE p.imported=0";
        if ($debug) {
            echo $sql;
        }
        $request = $db->Execute($sql);
        while ($row = $request->FetchRow()) {
            $payName = getPaytypeByName($row[paytype]);
            if ($row[amount] <> '') {
                $amount = $row[amount];
            } else {
                $amount = '0.00';
            }
            if ($row[Balance] <> '') {
                $balance = $row[Balance];
            } else {
                $balance = '0.00';
            }
            $sql2 = "insert into proll_payments(pid,emp_names,payDate,status,payMonth,catId,pay_type,amount,Balance)
                        values ('$row[pid]','$row[empnames]','$row[payDay]','$row[status]','$row[payMonth]','$row[catname]',"
                    . "'$row[paytype]','$amount','$balance')";
            if ($debug) {
                echo $sql2;
            }
            if ($db->Execute($sql2)) {
                $sqlUpdate = "Update proll_emp_payments set imported=1 where pid='$row[pid]' and payname='$payName'";
                if ($debug) {
                    echo $sqlUpdate;
                }
                if ($db->Execute($sqlUpdate)) {
                    $error = 0;
                } else {
                    $error = 3;
                }
            } else {
                $error = 2;
            }
        }
        if ($error == 0) {
            echo "{success:true}";
        } else {
            echo "{failure:true; error:$error}";
        }
    }

function verifyPaytypeExist($payName, $pid) {
    global $db;
    $debug = true;

    $sql = "Select payName from proll_emp_payments where pid='$pid' and payName='$payName'";
    $result = $db->Execute($sql);
    $numRows = $result->RecordCount();

    if ($numRows > 0) {
        return TRUE;
    } else {
        return FALSE;
    }
}

function InsertEmpPayment($pid, $payType, $payName, $amount, $balance) {
    global $db;
    $debug = false;

    if (verifyPaytypeExist($payName, $pid)) {
        echo "{'failure':'true', 'errNo':1,'payName':'$payName'}";
    } else {
        $sql = 'insert into proll_emp_payments(PID,PayType, PayName, Amount, Balance, Approved)
                values("' . $pid . '", "' . $payType . '", "' . $payName . '", "' . $amount . '","' . $balance . '",1)';
        if ($debug)
            echo $sql;
        if ($db->Execute($sql)) {
            echo '{success: true }';
        } else {
            echo "{'failure':'true','errNo':'2'}";
        }
    }
}

function updateItem($ID, $pid, $payType, $payName, $amount, $balance) {
    global $db;
    $debug = FALSE;

    $sql = 'update proll_emp_payments set Amount = "' . $amount . '" ,Balance ="' . $balance
            . '",Approved=1 WHERE ID=' . $ID;

    if ($debug)
        echo $sql;
    if ($db->Execute($sql)) {
        echo '{Success: true }';
    } else {
        echo "{'failure':'true','pid':'$pid'}";
    }
}

function getEmpPayments($pid, $start, $limit) {
    global $db;
    $debug = false;

    $json = $_REQUEST['editData'];
    $rctData = json_decode($json, TRUE);

    if (count($rctData) > 0) {
        updateItem($rctData[ID], $rctData[PID], $rctData[PayType], $rctData[PayName], $rctData[Amount], $rctData[Balance]);
    }

    $sql = 'SELECT p.`ID`,p.`PID`, k.`CatName`, c.`PayType`, p.`Amount`,p.Balance FROM proll_emp_payments p
                INNER JOIN proll_paycategory k ON k.id=p.`PayType`
                INNER JOIN proll_paytypes c ON c.id=p.PayName';

    if (isset($pid)) {
        $sql.=" where pid='$pid'";
    }

    if (isset($start) && isset($limit)) {
        $sql.=" limit $start,$limit";
    }


    if ($debug)
        echo $sql;
    $result = $db->Execute($sql);
    $numRows = $result->RecordCount();
    echo '{
    "empPayments":[';
    $counter = 0;
    while ($row = $result->FetchRow()) {
        $paytype = $desc = preg_replace('/[^a-zA-Z0-9_ -]/s', '', $row[CatName]);
        $PayName = $desc = preg_replace('/[^a-zA-Z0-9_ -]/s', '', $row[PayType]);
        echo '{"ID":"' . $row[ID] . '","PID":"' . $row[PID] . '","PayType":"' . $paytype . '",
            "PayName":"' . $PayName . '","Amount":"' . $row[4] . '","Balance":"' . $row[5] . '"}';
        if ($counter < $numRows) {
            echo ",";
        }
        $counter++;
    }
    echo ']}';
}

function getProllPayments($pid, $payMonth, $CatID, $payType, $start, $limit) {
    global $db;
    $debug = false;

    $json = $_REQUEST['editData'];
    $rctData = json_decode($json, TRUE);

    if (count($rctData) > 0) {
        updateItem($rctData[ID], $rctData[PID], $rctData[PayType], $rctData[PayName], $rctData[Amount], $rctData[Balance]);
    }

    $sql = "SELECT p.`ID`,p.`PID`, p.`CatID`, p.`pay_type`, p.`Amount`,p.Balance FROM proll_payments p where p.payMonth='$payMonth'";

    if (isset($pid)) {
        $sql.=" and p.pid='$pid'";
    }

    if (isset($start) && isset($limit)) {
        $sql.=" limit $start,$limit";
    }


    if ($debug)
        echo $sql;
    $result = $db->Execute($sql);
    $numRows = $result->RecordCount();
    echo '{
    "prollPayments":[';
    $counter = 0;
    while ($row = $result->FetchRow()) {
        $paytype = $desc = preg_replace('/[^a-zA-Z0-9_ -]/s', '', $row[CatID]);
        $PayName = $desc = preg_replace('/[^a-zA-Z0-9_ -]/s', '', $row[pay_type]);
        echo '{"ID":"' . $row[ID] . '","PID":"' . $row[PID] . '","PayType":"' . $paytype . '",
            "PayName":"' . $PayName . '","Amount":"' . $row[Amount] . '","Balance":"' . $row[Balance] . '"}';
        if ($counter < $numRows) {
            echo ",";
        }
        $counter++;
    }
    echo ']}';
}

function getPayRates() {
    global $db;
    $debug = false;

    $sql = 'SELECT `ID`,`RateName`,`Value`,`Lower_Limit`,`Upper_Limit`,`Rate` FROM `proll_rates`';

    if ($debug)
        echo $sql;

    $result = $db->Execute($sql);
    $numRows = $result->RecordCount();
    echo '{
    "payRates":[';
    $counter = 0;
    while ($row = $result->FetchRow()) {
        //$paytype = $desc = preg_replace('/[^a-zA-Z0-9_ -]/s', '', $row[RateName]);
        echo '{"ID":"' . $row[ID] . '","RateName":"' . $row[RateName] . '","Value":"' . $row[Value]
        . '","Lower_Limit":"' . $row[Lower_Limit] . '","Upper_Limit":"' . $row[Upper_Limit] . '","Rate":"' . $row[Rate] . '"}';
        $counter++;
        if ($counter <> $numRows) {
            echo ",";
        }
    }
    echo ']}';
}

function getPayTypes($CatID, $start, $limit) {
    global $db;
    $debug = false;

    $sql1 = "Select ID from proll_paytypes";
    $result1 = $db->Execute($sql1);
    $numRows = $result1->RecordCount();

    $sql = "SELECT   `ID`,`CatID`,`PayType`,`Fixed`,`Notes`,`Contribution`,`gl_acc`,`gl_desc`,`Posted`,
            `Interest`,`InterestCode`,`InterestName`,`Recurrent` FROM proll_paytypes ";

    if (isset($CatID)) {
        $sql.=" where CatID='$CatID'";
    }

    $sql.=" order by PayType asc";

    if (isset($start) && isset($limit)) {
        $sql.=" limit $start,$limit";
    }



    if ($debug)
        echo $sql;

    $result = $db->Execute($sql);
    //$numRows = $result->RecordCount();
    echo '{
    "total":"' . $numRows . '","payTypes":[';
    $counter = 0;
    while ($row = $result->FetchRow()) {
        $paytype = $desc = preg_replace('/[^a-zA-Z0-9_ -]/s', '', $row[PayType]);
        echo '{"ID":"' . $row[ID] . '","CatID":"' . $row[CatID] . '","PayType":"' . $paytype . '","Fixed":"' . $row[Fixed]
        . '","Contribution":"' . $row[Contribution] . '","gl_acc":"' . $row[gl_acc] . '","gl_desc":"' . $row[gl_desc] . '","Posted":"' . $row[Posted]
        . '","Interest":"' . $row[Interest] . '","InterestCode":"' . $row[InterestCode] . '","InterestName":"' . $row[InterestName] . '","Recurrent":"' . $row[Recurrent] . '"}';

        $counter++;
        if ($counter <> $numRows) {
            echo ",";
        }

    }
    echo ']}';
}

function insertNewEmployee($registerdetails) {
    global $db;
    $debug = false;

    //$table = $registerdetails['formtype'];
    unset($registerdetails['formStatus']);

    foreach ($registerdetails as $key => $value) {
        $FieldNames.=$key . ', ';
        $FieldValues.='"' . $value . '", ';
    }

    $sql = 'INSERT INTO proll_empregister (' . substr($FieldNames, 0, -2) . ') ' .
            'VALUES (' . substr($FieldValues, 0, -2) . ') ';

    if ($debug)
        echo $sql;
    if ($db->Execute($sql)) {
        echo '{success:true}';
    } else {
        echo "{'failure':'true','pid':'$registerdetails[PID]'}";
    }
}

function updateEmployee($registerdetails) {
    global $db;
    $debug = FALSE;
    $sql = 'UPDATE proll_empregister SET ';
    unset($registerdetails['formStatus']);
    foreach ($registerdetails as $key => $value) {
        $sql .= $key . '="' . $value . '", ';
    }
    $sql = substr($sql, 0, -2) . ' WHERE pid="' . $registerdetails['PID'] . '"';

    if ($debug)
        echo $sql;

    if ($db->Execute($sql)) {
        $results = '{success: true }';
    } else {
        $results = "{success: false,errors:{clientNo:'Could not update Debtor, Please check your values'}}"; // Return the error message(s)
    }
    echo $results;
}

function getMaritalStatus() {
    global $db;
    $sql = 'SELECT * FROM proll_Maritalstatus';
    $result = $db->Execute($sql);
    $numRows = $result->RecordCount();
    echo '{
    "maritalstatus":[';
    $counter = 0;
    while ($row = $result->FetchRow()) {
        echo '{"ID":"' . $row[ID] . '","maritals":"' . $row[maritals] . '"}';

        $counter++;

        if ($counter <> $numRows) {
            echo ",";
        }
    }
    echo ']}';
}

function getJobGroup() {
    global $db;
    $sql = 'SELECT ID,groupID,groupName,houseAllowance,leaveAllowance FROM proll_jobgroups p';
    $result = $db->Execute($sql);
    $numRows = $result->RecordCount();
    echo '{
    "jobGroups":[';
    $counter = 0;
    while ($row = $result->FetchRow()) {
        echo '{"ID":"' . $row[ID] . '","groupID":"' . $row[groupID] . '","groupID":"' . $row[groupID] . '","groupName":"' . $row[groupName] . '","houseAllowance":"' . $row[houseAllowance]
        . '","leaveAllowance":"' . $row[leaveAllowance] . '"}';
        if ($counter <> $numRows) {
            echo ",";
        }
        $counter++;
    }
    echo ']}';
}

function getEmpType() {
    global $db;
    $sql = 'SELECT `ID`, `EmpType`, `Duration` FROM `proll_emptypes`';
    $result = $db->Execute($sql);
    $numRows = $result->RecordCount();
    echo '{
    "empTypes":[';
    $counter = 0;
    while ($row = $result->FetchRow()) {
        echo '{"ID":"' . $row[0] . '","EmpType":"' . $row[1] . '","Duration":"' . $row[2] . '"}';
        if ($counter < $numRows) {
            echo ",";
        }
        $counter++;
    }
    echo ']}';
}

function getJobTitle() {
    global $db;
    $sql = 'SELECT p.`ID`, p.`JobTitle` FROM proll_jobtitles p';
    $result = $db->Execute($sql);
    $numRows = $result->RecordCount();
    echo '{
    "jobTitles":[';
    $counter = 0;
    while ($row = $result->FetchRow()) {
        echo '{"ID":"' . $row[0] . '","JobTitle":"' . $row[1] . '"}';
        if ($counter <> $numRows) {
            echo ",";
        }
        $counter++;
    }
    echo ']}';
}

function getBankBranch($bankid) {
    global $db;

    $sql = "SELECT ID, p.`BankBranch` FROM proll_bankbranches p";

    if (isset($bankid)) {
        $sql.=" where p.`bankid`=$bankid";
    }
    $result = $db->Execute($sql);
    $numRows = $result->RecordCount();
//    echo $sql;
    echo '{
    "bankbranches":[';
    $counter = 0;
    while ($row = $result->FetchRow()) {
        echo '{"ID":"' . $row[ID] . '","BankBranch":"' . $row[BankBranch] . '"}';
        if ($counter <> $numRows) {
            echo ",";
        }
        $counter++;
    }
    echo ']}';
}

function getBanks() {
    global $db;
    $sql = 'SELECT p.ID,p.bankcode,p.`BankName` FROM proll_banks p';
    $result = $db->Execute($sql);
    $numRows = $result->RecordCount();
    echo '{
    "banks":[';
    $counter = 0;
    while ($row = $result->FetchRow()) {
        echo '{"ID":"' . $row[ID] . '","BankCode":"' . $row[bankcode] . '","BankName":"' . $row[BankName] . '"}';
        if ($counter <> $numRows) {
            echo ",";
        }
        $counter++;
    }
    echo ']}';
}

function getPayDepts() {
    global $db;
    $sql = 'SELECT * FROM proll_departments p;';
    $result = $db->Execute($sql);
    $numRows = $result->RecordCount();
    echo '{
    "getDepts":[';
    $counter = 0;
    while ($row = $result->FetchRow()) {
        echo '{"ID":"' . $row[ID] . '","deptName":"' . $row[deptName] . '","BranchID":"' . $row[branchid] . '","gl_acc":"' . $row[gl_acc] . '"}';
        if ($counter <> $numRows) {
            echo ",";
        }
        $counter++;
    }
    echo ']}';
}

function getPayBranch() {
    global $db;
    $sql = 'SELECT * FROM proll_paybranch;';
    $result = $db->Execute($sql);
    $numRows = $result->RecordCount();
    echo '{
    "payBranches":[';
    $counter = 0;
    while ($row = $result->FetchRow()) {
        echo '{"ID":"' . $row[0] . '","BranchName":"' . $row[1] . '"}';
        if ($counter <> $numRows) {
            echo ",";
        }
        $counter++;
    }
    echo ']}';
}

function getEmployeeRecord($start, $limit, $pid) {
    global $db;
    $debug = false;
    $searchParam=$_REQUEST[searchParam];

    $sql = "SELECT PID,FirstName,LastName,SurName,Department,EmpBranch,JobTitle,Box,PostalCode,Phone,Town,Email,
            ID_No,Pin_No,NHIF_No,NSSF_No,Account_No,EmpType,AppointDate,AppointEndDate,
            ConfirmDate,Nationality,MaritalStatus,DOB,Sex,Housed,Unionisable,BankID,BranchID,JobGroup,
            Taxable,nssfDeduct,nhifDeduct,EmpStatus,Pensionable,GratuityRates,HELB_No,SaccoNo FROM proll_empregister where EmpStatus='Active'";

    if ($pid <> '') {
        $sql.=" pid= '$pid'";
    }

    if($searchParam<>''){
        $sql.=" and pid='$searchParam' or FirstName like '$searchParam%' or LastName like '$searchParam%' or SurName like '$searchParam%'";
    }

    if ($start <> '' && $limit <> '') {
        $sql.=" limit $start ,$limit";
    }

    if ($debug)
        echo $sql;

    $result = $db->Execute($sql);

    $sql2 = "select count(pid) from proll_empregister";
    $result2 = $db->Execute($sql2);
    $numRows = $result2->FetchRow();


    echo '{
    "total":"' . $numRows[0] . '","Employees":[';
    $counter = 0;
    while ($row = $result->FetchRow()) {
        echo '{"PID":"' . $row[PID] . '","FirstName":"' . $row[FirstName] . '","LastName":"' . $row[LastName] . '","SurName":"' . $row[SurName]
        . '","Department":"' . $row[Department] . '","JobTitle":"' . $row[JobTitle] . '",
        "Box":"' . $row[Box] . '","PostalCode":"' . $row[PostalCode] . '","Phone":"' . $row[Phone] . '","Town":"' . $row[Town] . '","Email":"' . $row[Email]
        . '","ID_No":"' . $row[ID_No] . '","Pin_No":"' . $row[Pin_No] . '","NHIF_No":"' . $row[NHIF_No] . '","NSSF_No":"' . $row[NSSF_No] . '",
        "Account_No":"' . $row[Account_No] . '","EmpType":"' . $row[EmpType] . '","AppointDate":"' . $row[AppointDate]
        . '","AppointEndDate":"' . $row[AppointEndDate] . '","ConfirmDate":"' . $row[ConfirmDate] . '","Nationality":"' . $row[Nationality] . '",
         "MaritalStatus":"' . $row[MaritalStatus] . '","DOB":"' . $row[DOB] . '","Sex":"' . $row[Sex] . '",
         "Housed":"' . $row[Housed] . '","Unionisable":"' . $row[Unionisable] . '",
         "BankID":"' . $row[BankID] . '","BranchID":"' . $row[BranchID] . '","EmpBranch":"' . $row['EmpBranch'] . '","JobGroup":"' . $row['JobGroup']
        . '","NSSF":"' . $row['nssfDeduct'] . '","NHIF":"' . $row['nhifDeduct'] . '","Taxable":"' . $row['Taxable'] . '","EmpStatus":"' . $row['EmpStatus']
        . '","Pensionable":"' . $row['Pensionable'] . '","GratuityRates":"' . $row['GratuityRates']
        . '","HELB_No":"' . $row['HELB_No'] . '","SaccoNo":"' . $row['SaccoNo']. '"}';

        if ($counter < $numRows) {
            echo ",";
        }
        $counter++;
    }
    echo ']}';
}

?>