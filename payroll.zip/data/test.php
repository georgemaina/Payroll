<?php
/**
 * Created by george maina
 * Email: georgemainake@gmail.com
 * Copyright: All rights reserved on 6/26/14.
 */
/**
 * Created by PhpStorm.
 * User: George Maina
 * Email:georgemainake@gmail.com
 * Copyright: All rights reserved
 * Date: 6/26/14
 * Time: 11:17 AM
 * 
 */

    Pid=4 EmpNames=GLADYS MWAURA WANGARI Amount=2000 Balance=

    INSERT INTO `proll_emp_payments` (`pid`,`PayType`,`PayName`, `Amount`,`Balance`)
            VALUES('4','','012','2000',' '){success:true} Pid=5 EmpNames=GEORGE OPANGA ONASSIS Amount=3000 Balance=

    INSERT INTO `proll_emp_payments` (`pid`,`PayType`,`PayName`, `Amount`,`Balance`)
            VALUES('5','','012','3000',' '){success:true}e'){success:true}