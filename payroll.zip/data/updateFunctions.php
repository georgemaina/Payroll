<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */



error_reporting(E_COMPILE_ERROR | E_ERROR | E_CORE_ERROR);
require_once('roots.php');
require ($root_path . 'include/inc_environment_global.php');

$limit = $_REQUEST[limit];
$start = $_REQUEST[start];

$task = ($_REQUEST['task']) ? ($_REQUEST['task']) : '';

$ID = $_POST[ID];
$tableName = $_POST[tableName];
$fieldParam = $_POST[fieldParam];
$valueParam = $_POST[fieldValue];

$itemdetails = $_POST;

$formStatus = $_POST[formStatus];
$userName = $_POST[userName];

switch ($task) {
    case "updateItems":
        if ($formStatus == 'update') {
            updateItem($itemdetails, $tableName, $fieldParam, $valueParam);
        } else {
            insertItem($itemdetails, $tableName, $fieldParam, $valueParam);
        }
        break;
    case "deleteItem":
        deleteItem($tableName, $fieldParam, $valueParam);
        break;
    default :
        echo '{failure:true}';
        break;
}

function deleteItem($tableName, $fieldParam, $valueParam) {
    global $db;
    $debug = false;

    $sql = "delete from $tableName where $fieldParam='$valueParam'";
    if ($debug) {
        echo $sql;
    }
    if ($db->Execute($sql)) {
        echo "{success:true}";
    } else {
        echo "{failure:false}";
    }
}

function validateItem($tableName, $fieldParam, $valueParam) {
    global $db;
    $debug = false;

    $sql = "Select $fieldParam from $tableName where $fieldParam='$valueParam'";
    if ($debug) {
        echo $sql;
    }
    $request = $db->Execute($sql);
    $numRows = $request->RecordCount();

    if ($numRows > 0) {
        return TRUE;
    } else {
        return FALSE;
    }
}

function insertItem($itemdetails, $tableName, $fieldParam, $valueParam) {
    global $db;
    $debug = false;

    //$table = $registerdetails['formtype'];
    if (validateItem($tableName, $fieldParam, $itemdetails["$fieldParam"])) {
        echo '{failure:true,"errNo":"1"}';
    } else {
        unset($itemdetails['formStatus']);
        if($tableName<>'proll_paytypes'){
            unset($itemdetails['ID']);
        }   
        unset($itemdetails['tableName']);
        unset($itemdetails['fieldParam']);
        unset($itemdetails['fieldValue']);

        foreach ($itemdetails as $key => $value) {
            $FieldNames.=$key . ', ';
            $FieldValues.='"' . $value . '", ';
        }

        $sql = "INSERT INTO $tableName (" . substr($FieldNames, 0, -2) . ")" .
                'VALUES (' . substr($FieldValues, 0, -2) . ') ';

        if ($debug)
            echo $sql;
        if ($db->Execute($sql)) {
            echo '{success:true}';
        } else {
            echo "{'failure':'true','errNo':'2'}";
        }
    }
}

function updateItem($itemdetails, $tableName, $fieldParam, $valueParam) {
    global $db;
    $debug = true;
    $id = $itemdetails['ID'];
    $paramField=$valueParam;
    $sql = "UPDATE $tableName SET ";
    unset($itemdetails['formStatus']);
    unset($itemdetails['ID']);
    unset($itemdetails['tableName']);
    unset($itemdetails['fieldParam']);
    unset($itemdetails['fieldValue']);

    foreach ($itemdetails as $key => $value) {
        $sql .= $key . '="' . $value . '", ';
    }
    $sql = substr($sql, 0, -2) . " WHERE $valueParam='" .$id . "'";

    if ($debug)
        echo $sql;

    if ($db->Execute($sql)) {
        $results = '{success: true }';
    } else {
        $results = "{failure: true}"; // Return the error message(s)
    }
    echo $results;
}
