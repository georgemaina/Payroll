<?php
# This is the database name
$dbname='chak_payroll';

# Database user name, default is root or httpd for mysql, or postgres for postgresql
$dbusername='root';

# Database user password, default is empty char
$dbpassword='355ewxxke';

# Database host name, default = localhost
$dbhost='localhost';

# First key used for simple chaining protection of scripts
$key='4.58869032405E+13';

# Second key used for accessing modules
$key_2level='3.14352182102E+12';

# 3rd key for encrypting cookie information
$key_login='3.92004887912E+13';

# Main host address or domain
$main_domain='localhost';

# Host address for images
$fotoserver_ip='localhost';

# Transfer protocol. Use https if this runs on SSL server
$httprotocol='http';

# Set this to your database type. For details refer to ADODB manual or goto http://php.weblogs.com/ADODB/
$dbtype='mysql';
?>