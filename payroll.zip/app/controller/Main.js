Ext.define('PayrollApp.controller.Main', {
    extend: 'Ext.app.Controller'
});
